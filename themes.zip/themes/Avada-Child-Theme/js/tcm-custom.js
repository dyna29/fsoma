

document.addEventListener("DOMContentLoaded", function() {
    let link;

    if (document.body.classList.contains('logged-in')) {
        // Logged in → Student Logout
        link = document.querySelector('a[href="#lolmiloginout#"]'); 
        if (link) {
            link.setAttribute("href", StudentAuth.logoutUrl); // nonce-safe URL
            const span = link.querySelector('span');
            if (span) span.textContent = "Logout";
        }
    } else {
        // Logged out → Student Login
        link = document.querySelector('a[href="#lolmiloginout#"]'); 
        if (link) {
            link.setAttribute("href", StudentAuth.loginUrl);
            const span = link.querySelector('span');
            if (span) span.textContent = "Student Login";
        }
    }
});

