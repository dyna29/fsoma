jQuery(document).ready(function($) {
    $('.toggle-featured').on('click', function(e) {
        e.preventDefault();

        var $el = $(this);
        var postId = $el.data('post-id');

        $.post(featuredToggleAjax.ajax_url, {
            action: 'toggle_featured_status',
            post_id: postId,
            _ajax_nonce: featuredToggleAjax.nonce
        }, function(response) {
            if (response.success) {
                var newValue = response.data;
                $el.text(newValue)
                   .removeClass('featured-yes featured-no')
                   .addClass(newValue === 'Yes' ? 'featured-yes' : 'featured-no');
            }
        });
    });
});
