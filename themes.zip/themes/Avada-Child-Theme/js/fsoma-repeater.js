jQuery(document).ready(function($){
    var $wrapper = $('#fsoma-other-products-wrapper');
    var $template = $('#fsoma-other-row-template').html();

    function nextIndex(){
        return $wrapper.find('.fsoma-other-row').length;
    }

    $('#fsoma-add-row').on('click', function(e){
        e.preventDefault();
        var idx = nextIndex();
        var html = $template.replace(/__INDEX__/g, idx);
        var $row = $(html);
        $wrapper.append($row);
        $('html, body').animate({ scrollTop: $row.offset().top - 100 }, 150);
    });

    $wrapper.on('click', '.fsoma-remove-row', function(e){
        e.preventDefault();
        if ( confirm('Remove this product?') ){
            $(this).closest('.fsoma-other-row').remove();
            // reindex names: fsoma_other_products[0][product], [0][description], etc.
            $wrapper.find('.fsoma-other-row').each(function(i){
                $(this).find('select, input, textarea').each(function(){
                    var name = $(this).attr('name');
                    if (!name) return;
                    // replace first bracketed index only
                    var newName = name.replace(/\[\d+\]/, '['+i+']');
                    $(this).attr('name', newName);
                });
            });
        }
    });
});
