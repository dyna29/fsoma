<?php

function theme_enqueue_styles() {
    wp_enqueue_style( 'avada-parent-stylesheet', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );

function avada_lang_setup() {
	$lang = get_stylesheet_directory() . '/languages';
	load_child_theme_textdomain( 'Avada', $lang );
}
add_action( 'after_setup_theme', 'avada_lang_setup' );

// To change add to cart text on single product page
add_filter( 'woocommerce_product_single_add_to_cart_text', 'woocommerce_custom_single_add_to_cart_text' ); 
function woocommerce_custom_single_add_to_cart_text() {
    return __( 'Buy Now', 'woocommerce' ); 
}

// To change add to cart text on product archives(Collection) page
add_filter( 'woocommerce_product_add_to_cart_text', 'woocommerce_custom_product_add_to_cart_text' );  
function woocommerce_custom_product_add_to_cart_text() {
    return __( 'Buy Now', 'woocommerce' );
}

// add_action( 'wp_print_styles', 'pp_deregister_styles', 99 );
 
// function pp_deregister_styles() {
//  wp_deregister_style( 'wlcl_front_css-css' ); 
//   wp_deregister_style( 'ppcore' );
//  wp_deregister_style( 'pp-social-button' );
//  wp_deregister_style( 'pp-flat-ui' );
//  wp_deregister_style( 'pp-bootstrap' );
//  wp_deregister_style( 'pp-chosen' ); 
// } 
// function pluginslug_enqueue_style() {
// 	wp_dequeue_style( 'wlcl_front_css-css' ); 
// }

// add_action( 'wp_enqueue_scripts', 'pluginslug_enqueue_style' ); 

if ( is_user_logged_in() ) {
    $user_id = get_current_user_id();
    $value = '';
    delete_user_meta($user_id, 'stripe_cust_id', $value);
}

add_action( 'wp_footer', 'trigger_for_ajax_add_to_cart' );
function trigger_for_ajax_add_to_cart() {
    ?>
    <script type="text/javascript">
        (function($){
            $('.ajax_add_to_cart').click(function(){
            //$(document.body).on("added_to_cart", function (event, fragments, cart_hash, $button) {
                let product_id = $(this).attr('data-product_id');
                //Biomedicine popup
                // if($($button[0]).data('product_id') == 39177 || $($button[0]).data('product_id') == 39176 || $($button[0]).data('product_id') == 39168 ){
                if(product_id == 39177 || product_id == 39176 || product_id == 39168 ){
                    $('.cart-loading').hide();
                    PUM.open(39964);
                //Herbology popup
                // }else if($($button[0]).data('product_id') == 39169 || $($button[0]).data('product_id') == 39178 || $($button[0]).data('product_id') == 39179 ){
                }else if(product_id == 39169 || product_id == 39178 || product_id == 39179 ){
                    $('.cart-loading').hide();
                    PUM.open(39981);
                //Foundations popup
                // }else if($($button[0]).data('product_id') == 39173 || $($button[0]).data('product_id') == 39172 || $($button[0]).data('product_id') == 39166 ){
                }else if(product_id == 39173 || product_id == 39172 || product_id == 39166 ){
                    $('.cart-loading').hide();
                    PUM.open(39983);
                //Acupuncture popup
                // }else if($($button[0]).data('product_id') == 39175 || $($button[0]).data('product_id') == 39174 || $($button[0]).data('product_id') == 39167 ){
                }else if(product_id == 39175 || product_id == 39174 || product_id == 39167 ){
                    $('.cart-loading').hide();
                    PUM.open(39985);
                //CALE Popup
                // }else if($($button[0]).data('product_id') == 39171 || $($button[0]).data('product_id') == 39182 || $($button[0]).data('product_id') == 39194 ){
                }else if(product_id == 39171 || product_id == 39182 || product_id == 39194 ){
                    $('.cart-loading').hide();
                    PUM.open(39987);
                //NCCAOM Popup
                // }else if($($button[0]).data('product_id') == 39170 || $($button[0]).data('product_id') == 39180 || $($button[0]).data('product_id') == 39181 ){
                }else if(product_id == 39170 || product_id == 39180 || product_id == 39181 ){
                    $('.cart-loading').hide();
                    PUM.open(39989);
                }else if(product_id == 43393 || product_id == 43377 || product_id == 43376 || product_id == 43386 || product_id == 43387 || product_id == 43388 ){
                    $('.cart-loading').hide();
                    PUM.open(43516);
				}else if(product_id == 43382 || product_id == 43381 || product_id == 43380 || product_id == 43374 || product_id == 43372 || product_id == 43373 ){
                    $('.cart-loading').hide();
                    PUM.open(43520);
                }else if(product_id == 43367 || product_id == 43368 || product_id == 43365 ){
                    $('.cart-loading').hide();
                    PUM.open(43522);
                }else if(product_id == 43384 || product_id == 43383 || product_id == 43379 ){
                    $('.cart-loading').hide();
                    PUM.open(43521);
                }else if(product_id == 39260 || product_id == 39246 || product_id == 39234 || product_id == 39220 || product_id == 39208 || product_id == 43300 || product_id == 43302 || product_id == 43289){
                    //look every 100ms for .awb-icon-check-square-o length and verify if is major than 1655555555555555555555555555
                    let timeWait = 3000;
                    //if pum-conteiner .product-images length > 1 then timeWait = 10000
                    if(jQuery('.pum-container:visible .product-images').length > 1){
                        timeWait = 10000;
                    }
                    let checkInterval = setInterval(function(){
                        if(jQuery('.awb-icon-spinner:visible').length < 1){
                            clearInterval(checkInterval);
                            clickOnPopupClose();
                        }
                    }, timeWait);
                }
            });
        })(jQuery);
        function clickOnPopupClose(){
            jQuery('.pum-close.popmake-close').click();
        }
        function clickUpdateCart(){
            jQuery('.fusion-update-cart').click();
        }
        jQuery(document).ready(function(){
            jQuery('.input-text.qty.text').change(function(){
                jQuery('.single_add_to_cart_button').attr('data-quantity',jQuery(this).val());
            })
            let clickTimeout;
            jQuery('body').on('click','.woocommerce-cart-form__cart-item .quantity .plus, .woocommerce-cart-form__cart-item .quantity .minus',function(){
                clearTimeout(clickTimeout);
                clickTimeout = setTimeout(clickUpdateCart, 1000);
            })
        })
    </script>
    <style>
        .pum-container .price bdi {text-decoration: line-through;}
        .pum-container .post-39260 .price .woocommerce-Price-amount.amount::after,
        .pum-container .post-39246 .price .woocommerce-Price-amount.amount::after{
            margin-left: 5px; content: '$22.50'; text-decoration: underline;
        }
        .pum-container .post-39220 .price .woocommerce-Price-amount.amount::after,
        .pum-container .post-39234 .price .woocommerce-Price-amount.amount::after{
            margin-left: 5px; content: '$17.50'; text-decoration: underline;
        }
		.pum-container .post-43300 .price .woocommerce-Price-amount.amount::after{
            margin-left: 5px; content: '$35.00'; text-decoration: underline;
        }
		.pum-container .post-43302 .price .woocommerce-Price-amount.amount::after{
            margin-left: 5px; content: '$40.00'; text-decoration: underline;
        }
		.pum-container .post-43289 .price .woocommerce-Price-amount.amount::after{
            margin-left: 5px; content: '$30.00'; text-decoration: underline;
        }
        #popmake-39987.pum-container .price .woocommerce-Price-amount.amount::after{
            margin-left: 5px; content: '$40.00'; text-decoration: underline;
        }
    </style>
    <?php
}

/**
 * @snippet       Add Custom Field @ WooCommerce Checkout Page if customer are buying a course
 * @how-to        Get CustomizeWoo.com FREE
 * @author        Rodolfo Melogli
 * @testedwith    WooCommerce 3.8
 * @donate $9     https://businessbloomer.com/bloomer-armada/
 */

//add_action( 'woocommerce_after_checkout_billing_form', 'wlm_custom_checkout_fields' );

function wlm_custom_checkout_fields( $checkout ) {

	$products_ids = array(39194,39180,39178,39179,39181,39182,39171,39177,39176,39175,39174,39173,39172,39170,39169,39168,39167,39166);
	$course_on_cart = false;

	foreach($products_ids as $product_id){
		if(WC()->cart->find_product_in_cart( WC()->cart->generate_cart_id( $product_id ) )){
			$course_on_cart = true;
		}
	}

	if( $course_on_cart ) {
		global $wpdb;
		$tableName = $wpdb->prefix."wlm_user_options";
		$cUserId = get_current_user_id();

		$domain = 'woocommerce';
		$checkout = WC()->checkout;

		$results = $wpdb->get_row( "SELECT option_value FROM ".$tableName." WHERE option_name = 'custom_type_place' AND user_id = ".$cUserId );

		echo '<div id="my_custom_checkout_field">';

		woocommerce_form_field( 'type_place', array(
			'type'          => 'text',
			'label'         => __('Name of School Attending or Attended', $domain ),
			'placeholder'   => __('', $domain ),
			'class'         => array('form-row form-row-wide thwcfd-field-wrapper'),
			'required'      => true, // or false
		), $results->option_value );

		echo '</div>';
	}
}

// Custom checkout fields validation
//add_action( 'woocommerce_checkout_process', 'wlm_custom_checkout_fields_process' );
function wlm_custom_checkout_fields_process() {
	if ( isset($_POST['_my_field_name']) && empty($_POST['_my_field_name']) )
		wc_add_notice( __( 'Please fill in "Name of School Attending or Attended".' ), 'error' );
}

// Save custom checkout fields the data to the order
//add_action( 'woocommerce_checkout_create_order', 'wlm_custom_checkout_fields_update_meta', 0, 2 );
//add_action( 'user_register', 'wlm_custom_checkout_fields_update_meta', 10, 2 );
function wlm_custom_checkout_fields_update_meta( $order, $data ){
	$cUserId = get_current_user_id();

	//verify if user is logged
	if($cUserId <= 0){
		if( isset($_POST['type_place']) && ! empty($_POST['type_place'])){
			$order->update_meta_data( 'type_place', sanitize_text_field( $_POST['type_place'] ) );
		}
	}
}
//add_action('wp_login', 'wlm_custom_checkout_guest_fields_update_meta');
//add_action('wishlistmember_after_registration ', 'wlm_custom_checkout_guest_fields_update_meta');
//add_action( 'woocommerce_payment_complete', 'wlm_custom_checkout_guest_fields_update_meta' ,0);
function wlm_custom_checkout_guest_fields_update_meta($order_id){
	global $wpdb;
	$tableName = $wpdb->prefix."wlm_user_options";

	$order = wc_get_order( $order_id );

	//$user = get_user_by('email', $_POST['billing_email']);
	$cUserId = $order->get_customer_id();

	//verify if user is logged
	if($cUserId > 0){

		$type_place = get_post_meta($order_id,'type_place',true);

		if( isset($type_place) && !empty($type_place)){
			$info = array('option_value' => $type_place);

			$result = $wpdb->update($tableName, $info, array('user_id' => $cUserId, 'option_name' => 'custom_type_place'));
			//If nothing found to update, it will try and create the record.
			if ($result === FALSE || $result < 1) {
				$info = array('user_id'=> $cUserId,'option_name' => 'custom_type_place', 'option_value' => $type_place);
				$wpdb->insert($tableName, $info);
			}

			$info = array('option_value' => $order->get_billing_phone());

			$result = $wpdb->update($tableName, $info, array('user_id' => $cUserId, 'option_name' => 'custom_phone'));
			//If nothing found to update, it will try and create the record.
			if ($result === FALSE || $result < 1) {
				$info = array('user_id'=> $cUserId,'option_name' => 'custom_phone', 'option_value' => $order->get_billing_phone());
				$wpdb->insert($tableName, $info);
			}
		}
	}
}

//add_action('wp_head', 'add_clarity_code');
function add_clarity_code(){ ?>
<script type="text/javascript">
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", "e5z0y5qjly");
</script>
<?php  
}

remove_filter('woocommerce_paypal_payments_checkout_button_renderer_hook','woocommerce_review_order_after_payment');
remove_filter('woocommerce_paypal_payments_checkout_dcc_renderer_hook','woocommerce_review_order_after_submit');
remove_filter('woocommerce_paypal_payments_pay_order_dcc_renderer_hook','woocommerce_pay_order_after_submit');

add_filter('woocommerce_paypal_payments_checkout_button_renderer_hook', function() {
	return 'woocommerce_review_order_before_submit';
});

add_filter('woocommerce_paypal_payments_checkout_dcc_renderer_hook', function() {
	return 'woocommerce_review_order_before_submit';
});

add_filter('woocommerce_paypal_payments_pay_order_dcc_renderer_hook', function() {
	return 'woocommerce_review_order_before_submit';
});

add_action( 'woocommerce_checkout_update_order_review', 'bbloomer_save_checkout_values', 9999 );

function bbloomer_save_checkout_values( $posted_data ) {
	parse_str( $posted_data, $output );
	WC()->session->set( 'checkout_data', $output );
}

add_filter( 'woocommerce_checkout_get_value', 'bbloomer_get_saved_checkout', 9999, 2 );

function bbloomer_get_saved_checkout( $value, $index ) {
	$data = WC()->session->get( 'checkout_data' );
	if ( ! $data || empty( $data[$index] ) ) return $value;
	return is_bool( $data[$index] ) ? (int) $data[$index] : $data[$index];
}

add_filter( 'woocommerce_ship_to_different_address_checked', 'bbloomer_get_saved_ship_to_different' );

function bbloomer_get_saved_ship_to_different( $checked ) {
	$data = WC()->session->get( 'checkout_data' );
	if ( ! $data || empty( $data['ship_to_different_address'] ) ) return $checked;
	return true;
}

//sanitize function
function sanitize( array $assoc_array ): array {
	$data = array();
	foreach ( (array) $assoc_array as $raw_key => $raw_value ) {
		if ( ! is_array( $raw_value ) ) {
			// Not sure if it is a good idea to sanitize everything at this level,
			// but should be fine for now since we do not send any HTML or multi-line texts via ajax.
			$data[ sanitize_text_field( (string) $raw_key ) ] = sanitize_text_field( (string) $raw_value );
			continue;
		}
		$data[ sanitize_text_field( (string) $raw_key ) ] = sanitize( $raw_value );
	}
	return $data;
}

//action init
add_action('init', 'fix_marketing_field');

function fix_marketing_field(){
	if($_REQUEST['wc-ajax'] == 'ppc-create-order'){
		$stream = file_get_contents( 'php://input' );
		$json   = json_decode( $stream, true );
		$sanitized = sanitize( $json );
		$_POST['demographic_marketing'] = explode(',',$sanitized['form']['demographic_marketing_hidden']);
	}
}

//create hidden demographic_marketing_hidden field on checkout form
add_action( 'woocommerce_after_checkout_billing_form', 'add_demographic_marketing_hidden_field' );
function add_demographic_marketing_hidden_field( $checkout ) {
	echo '<input type="hidden" name="demographic_marketing_hidden" id="demographic_marketing_hidden" value="" />';
}


//create javascript every time select multiple change save all value implode on hidden field
add_action( 'wp_footer', 'add_demographic_marketing_hidden_field_js' );
function add_demographic_marketing_hidden_field_js() {
	?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#demographic_marketing').on('change', function() {
                var selected = $(this).find('option:selected');
                var values = $.map(selected, function(element) {
                    return element.value;
                });
                $('#demographic_marketing_hidden').val(values.join(','));
            });
            $('#customer_details .continue-checkout, .woocommerce-checkout-nav li a').click(function(e){
                if($('#demographic_marketing').val() == ''){
                    if($('form.woocommerce-checkout').find('.woocommerce-error').length < 1) {
                        $('#demographic_marketing_field span.selection .select2-selection').css('border-color', 'red');
                        $('form.woocommerce-checkout').prepend('<ul class="woocommerce-error" role="alert"><li><strong>Billing How did you hear about us?</strong> is a required field.</li></ul>');
                    }
                    e.stopPropagation();
                }else{
                    $('#demographic_marketing_field span.selection .select2-selection').css('border-color','black');
                    $('form.woocommerce-checkout').find('.woocommerce-error').remove();
                }
            })
        });
    </script>
	<?php
}

//create javascript on page load save select multiple all value implode on hidden field
add_action( 'wp_footer', 'add_demographic_marketing_hidden_field_js_on_load' );
function add_demographic_marketing_hidden_field_js_on_load() {
	?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            var selected = $('#demographic_marketing').find('option:selected');
            var values = $.map(selected, function(element) {
                return element.value;
            });
            $('#demographic_marketing_hidden').val(values.join(','));
        });
    </script>
	<?php
}

//add_action( 'woocommerce_before_calculate_totals', 'add_discount_to_cart_3months' );
//add_action( 'woocommerce_before_calculate_totals', 'add_discount_to_cart_6months' );
//add_action( 'woocommerce_before_calculate_totals', 'add_discount_to_cart_12months' );
function add_discount_to_cart_3months( $cart ) {
    $products = array(39166,39169,39168,39167);
    $products_in_cart = array();
    $products_in_cart_count = 0;
    foreach ( $cart->get_cart() as $cart_item ) {
        if(in_array($cart_item['product_id'], $products)){
            if($cart_item['quantity'] > 1) return false;
            $products_in_cart[] = $cart_item['product_id'];
            $products_in_cart_count++;
        }
    }
    if($products_in_cart_count == 2){
        $discount = 3.96;
        //$discount = 12.94;
        foreach ( $cart->get_cart() as $cart_item ) {
            if(in_array($cart_item['product_id'], $products_in_cart)){
                //adicionar preço regular e preço de venda
                $cart_item['data']->set_regular_price( $cart_item['data']->get_price() );
                $cart_item['data']->set_sale_price( $cart_item['data']->get_price() - $discount);
                $cart_item['data']->set_price( $cart_item['data']->get_price() - $discount);
            }
        }
    }elseif($products_in_cart_count == 3){
        $discount = 3.96;
        //$discount = 12.24;
        foreach ( $cart->get_cart() as $cart_item ) {
            if(in_array($cart_item['product_id'], $products_in_cart)){
                //adicionar preço regular e preço de venda
                $cart_item['data']->set_regular_price( $cart_item['data']->get_price() );
                $cart_item['data']->set_sale_price( $cart_item['data']->get_price() - $discount);
                $cart_item['data']->set_price( $cart_item['data']->get_price() - $discount);
            }
        }
    }
}

function add_discount_to_cart_6months( $cart ) {
    $products = array(39178,39176,39174,39173);
    $products_in_cart = array();
    $products_in_cart_count = 0;
    foreach ( $cart->get_cart() as $cart_item ) {
        if(in_array($cart_item['product_id'], $products)){
            if($cart_item['quantity'] > 1) return false;
            $products_in_cart[] = $cart_item['product_id'];
            $products_in_cart_count++;
        }
    }
    if($products_in_cart_count == 2){
        $discount = 11.6;
        //$discount = 24.94;
        foreach ( $cart->get_cart() as $cart_item ) {
            if(in_array($cart_item['product_id'], $products_in_cart)){
                //adicionar preço regular e preço de venda
                $cart_item['data']->set_regular_price( $cart_item['data']->get_price() );
                $cart_item['data']->set_sale_price( $cart_item['data']->get_price() - $discount);
                $cart_item['data']->set_price( $cart_item['data']->get_price() - $discount);
            }
        }
    }elseif($products_in_cart_count == 3){
        $discount = 11.6;
        //$discount = 24.94;
        foreach ( $cart->get_cart() as $cart_item ) {
            if(in_array($cart_item['product_id'], $products_in_cart)){
                //adicionar preço regular e preço de venda
                $cart_item['data']->set_regular_price( $cart_item['data']->get_price() );
                $cart_item['data']->set_sale_price( $cart_item['data']->get_price() - $discount);
                $cart_item['data']->set_price( $cart_item['data']->get_price() - $discount);
            }
        }
    }
}

function add_discount_to_cart_12months( $cart ) {
    $products = array(39179,39177,39175,39172);
    $products_in_cart = array();
    $products_in_cart_count = 0;
    foreach ( $cart->get_cart() as $cart_item ) {
        if(in_array($cart_item['product_id'], $products)){
            if($cart_item['quantity'] > 1) return false;
            $products_in_cart[] = $cart_item['product_id'];
            $products_in_cart_count++;
        }
    }
    if($products_in_cart_count == 2){
        $discount = 24;
        //$discount = 41.6;
        foreach ( $cart->get_cart() as $cart_item ) {
            if(in_array($cart_item['product_id'], $products_in_cart)){
                //adicionar preço regular e preço de venda
                $cart_item['data']->set_regular_price( $cart_item['data']->get_price() );
                $cart_item['data']->set_sale_price( $cart_item['data']->get_price() - $discount);
                $cart_item['data']->set_price( $cart_item['data']->get_price() - $discount);
            }
        }
    }elseif($products_in_cart_count == 3){
        $discount = 24;
        //$discount = 41.6;
        foreach ( $cart->get_cart() as $cart_item ) {
            if(in_array($cart_item['product_id'], $products_in_cart)){
                //adicionar preço regular e preço de venda
                $cart_item['data']->set_regular_price( $cart_item['data']->get_price() );
                $cart_item['data']->set_sale_price( $cart_item['data']->get_price() - $discount);
                $cart_item['data']->set_price( $cart_item['data']->get_price() - $discount);
            }
        }
    }
}

function send_order_to_lulu($order_id){
    $order = wc_get_order( $order_id );

    $booksInfo = array();

    $items = $order->get_items();

    $tempBook = array();
    $tempBookCases = array();
    $line_items= array();
	
	$tempBook['pod_package_id'] = '0850X1100BWSTDPB060UW444MXX';
    $tempBook['title'] = 'The Official TCM Review Seminar\'s Textbook for the Pan Canadian Herbology Exam';
    $tempBook['cover'] = 'https://www.dropbox.com/s/0p5iix6vew4yrbr/1.%20Herbology%20Book%20Cover%20%281%29.pdf?dl=1';
    $tempBook['interior'] = 'https://www.dropbox.com/s/ksqgd2vfbib8x64/2.%20Herbology%20-%20PanCan%20-%20with%20new%202022%20Herbs.pdf?dl=1';
	
    $booksInfo[43289] = $tempBook;

    $tempBook['pod_package_id'] = '0850X1100BWSTDPB060UW444MXX';
    $tempBook['title'] = 'The Official TCM Review Seminar\’s Textbook for the Pan Canadian Written Exam';
    $tempBook['cover'] = 'https://www.dropbox.com/s/a88fcveos6l7hvp/1.%20Written%20Exam%20Book%20Cover.pdf?dl=1';
    $tempBook['interior'] = 'https://www.dropbox.com/s/g50j6qn2i70h8fb/2.%202021%20PanCanadian%20Written%20Exam%20Course%20-%208.5x11%20-%20R8.pdf?dl=1';

    $booksInfo[43300] = $tempBook;

    $tempBook['pod_package_id'] = '0827X1169BWSTDPB060UW444MXX';
    $tempBook['title'] = 'The Official TCM Review Seminar\'s Textbook for the Pan Canadian Clinical Case Studies Exam';
    $tempBook['cover'] = 'https://www.dropbox.com/s/gu6mrjnivoc7s6r/2.%20Clincal%20Case%20Studies%20Book%20Cover.pdf?dl=1';
    $tempBook['interior'] = 'https://www.dropbox.com/s/j53e0ucx1kuo5cy/1.%20Clinical%20Case%20Studies%20-%203rd%20Ed%20-%20R6.pdf?dl=1';

    $booksInfo[43302] = $tempBook;

    $tempBook['pod_package_id'] = '0850X1100BWSTDPB060UW444MXX';
    $tempBook['title'] = 'The Official TCM Review Seminars Textbook for NCCAOM Foundations Exam';
    $tempBook['cover'] = 'https://www.dropbox.com/s/luox2rzkogzoalj/1.%20Foundations%20Book%20%20Cover.pdf?dl=1';
    $tempBook['interior'] = 'https://www.dropbox.com/s/q6vbye28xmi67je/2.%20Foundations%20Book.pdf?dl=1';

    $booksInfo[39234] = $tempBook;

    $tempBook['pod_package_id'] = '0850X1100BWSTDPB060UW444MXX';
    $tempBook['title'] = 'The Official TCM Review Seminars Textbook for NCCAOM Biomedicine Exam';
    $tempBook['cover'] = 'https://www.dropbox.com/s/1k4rrobbp296glg/1.%20Biomedicine%20Book%20Cover.pdf?dl=1';
    $tempBook['interior'] = 'https://www.dropbox.com/s/phv810wh7leak1e/2.%20Biomedicine%20Book%20-%20R4.pdf?dl=1';

    $booksInfo[39260] = $tempBook;

    $tempBook['pod_package_id'] = '0850X1100BWSTDPB060UW444MXX';
    $tempBook['title'] = 'The Official TCM Review Seminars Textbook for NCCAOM Acupuncture Exam';
    $tempBook['cover'] = 'https://www.dropbox.com/s/l7co8hep4apqlev/1.%20Acupuncture%20Book%20Cover.pdf?dl=1';
    $tempBook['interior'] = 'https://www.dropbox.com/s/1p0ojkb6090cess/2.%20Acupuncture%20Book%20-%20R5.pdf?dl=1';

    $booksInfo[39220] = $tempBook;
	
	$tempBook['pod_package_id'] = '0850X1100BWSTDPB060UW444MXX';
    $tempBook['title'] = 'The Official TCM Review Seminars Textbook for NCCAOM Herbology Exam';
    $tempBook['cover'] = 'https://www.dropbox.com/s/jnxhm67l2y9oq0a/1.%20Herbology%20Book%20Cover.pdf?dl=1';
    $tempBook['interior'] = 'https://www.dropbox.com/s/kzjx851ni69g9pm/2.%20Herbology%20%20Book%20-R10.pdf?dl=1';

    $booksInfo[39246] = $tempBook;

    $tempBook['pod_package_id'] = '0850X1100BWSTDPB060UW444MXX';
    $tempBook['title'] = 'The Official TCM Review Seminars Textbook for CALE Course Readers';
    $tempBook['cover'] = 'https://www.dropbox.com/s/b6imoi6rawzkyl2/1.%20CALE%20Course%20Book%20Cover.pdf?dl=1';
    $tempBook['interior'] = 'https://www.dropbox.com/s/0gcslpmu6toj0gi/2.%20CALE%20Course%20Book%202021%20-%20R1.pdf?dl=1';

    $tempBookCases['pod_package_id'] = '0850X1100BWSTDPB060UW444MXX';
    $tempBookCases['title'] = 'The Official TCM Review Seminars Textbook for CALE Case Studies';
    $tempBookCases['cover'] = 'https://www.dropbox.com/s/d8w8wj3d7tnz34b/1.%20CALE%20Case%20Studies%20Book%20Cover.pdf?dl=1';
    $tempBookCases['interior'] = 'https://www.dropbox.com/s/i9xymw08k506ta9/2.%20CALE-%20Case%20Studies%20-%202023%203-15%20update%28M%29.pdf?dl=1';
	
    $booksInfo[39208] = $tempBook;

	$calecourses = array(39194,39182,39171);
	
	$nccaomBooks = array(39260,39220,39246,39234);
	
	$calecoursesbuy = false;
	
	foreach($items as $item){
		$itemID = $item->get_product_id();
        if(in_array($itemID, $calecourses)){
			$calecoursesbuy = true;
			break;
		}
	}
	
    foreach($items as $item){
        $itemID = $item->get_product_id();
        if(!array_key_exists($itemID, $booksInfo)) continue;
        if($itemID == 39208){
			//add case studies to $line_items
            $line_items_temp = array();
            $line_items_temp['external_id'] = $itemID.'999';
            $line_items_temp['printable_normalization']['cover']['source_url'] = $tempBookCases['cover'];
            $line_items_temp['printable_normalization']['interior']['source_url'] = $tempBookCases['interior'];
            $line_items_temp['printable_normalization']['pod_package_id'] = $tempBookCases['pod_package_id'];
            $line_items_temp['quantity'] = $item->get_quantity();
            $line_items_temp['title'] = $tempBookCases['title'];
            $line_items[] = $line_items_temp;
			
			//if($calecoursesbuy){
            //change ifs and dates when CALE promotion return
            if(false){
                //verify if current date is between 2023-08-01 00:00 and 2023-09-26 06:00 on pacific time
                $currentDate = new DateTime('now', new DateTimeZone('America/Los_Angeles'));
                $startDate = new DateTime('2023-08-01 00:00', new DateTimeZone('America/Los_Angeles'));
                $endDate = new DateTime('2023-09-26 04:00', new DateTimeZone('America/Los_Angeles'));

                if($currentDate >= $startDate && $currentDate <= $endDate){
                    //add nccaom course readers to $line_items
                    foreach ($nccaomBooks as $nccaomBook){
                        $line_items_temp = array();
                        $line_items_temp['external_id'] = $nccaomBook;
                        $line_items_temp['printable_normalization']['cover']['source_url'] = $booksInfo[$nccaomBook]['cover'];
                        $line_items_temp['printable_normalization']['interior']['source_url'] = $booksInfo[$nccaomBook]['interior'];
                        $line_items_temp['printable_normalization']['pod_package_id'] = $booksInfo[$nccaomBook]['pod_package_id'];
                        $line_items_temp['quantity'] = $item->get_quantity();
                        $line_items_temp['title'] = $booksInfo[$nccaomBook]['title'];
                        $line_items[] = $line_items_temp;
                    }

                    send_email_about_one_and_done($order_id,$endDate->format('F jS, Y'));
                }
            }
		}
		$line_items_temp = array();
		$line_items_temp['external_id'] = $itemID;
		$line_items_temp['printable_normalization']['cover']['source_url'] = $booksInfo[$itemID]['cover'];
		$line_items_temp['printable_normalization']['interior']['source_url'] = $booksInfo[$itemID]['interior'];
		$line_items_temp['printable_normalization']['pod_package_id'] = $booksInfo[$itemID]['pod_package_id'];
		$line_items_temp['quantity'] = $item->get_quantity();
		$line_items_temp['title'] = $booksInfo[$itemID]['title'];
		$line_items[] = $line_items_temp;
    }
	
    if(count($line_items) <= 0) return true;

    $apiResponse = wp_remote_post('https://api.lulu.com/auth/realms/glasstree/protocol/openid-connect/token',array(
        'headers' => array(
            'Content-Type' => 'application/x-www-form-urlencoded',
            'Authorization' => 'Basic MTcxNGQxMDYtNmViYi00Y2I4LTk5M2EtYzY2MGY2ZTcyZWM3OmU0MmIzN2JhLWRjMjctNDBiYi1hODUwLWFkMjlhZjc4NWY2OQ=='
        ),
        'body' => array(
            'grant_type' => 'client_credentials'
        )
    ));

    $bodyResponse = json_decode(wp_remote_retrieve_body($apiResponse));
    $access_token = $bodyResponse->access_token;

    $order = wc_get_order( $order_id );

    $shipping_level = get_option(str_replace(' ', '_', $order->get_shipping_method()), 'MAIL');

    $body = array(
        "contact_email" => "bina@tcmreview.com",
        "external_id" => $order_id,
        "line_items" => $line_items,
        "shipping_address" => array(
            "city" => $order->get_shipping_city(),
            "country_code" => $order->get_shipping_country(),
            "name" => $order->get_shipping_first_name().' '.$order->get_shipping_last_name(),
            "phone_number" => ($order->get_shipping_phone()) ? $order->get_shipping_phone() : $order->get_billing_phone(),
            "postcode" => $order->get_shipping_postcode(),
            "state_code" => $order->get_shipping_state(),
            "street1" => $order->get_shipping_address_1(),
            "street2" => $order->get_shipping_address_2()
        ),
        "shipping_level" => $shipping_level
    );

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, 'https://api.lulu.com/print-jobs');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));

    $headers = array();
    $headers[] = 'Authorization: Bearer '.$access_token;
    $headers[] = 'Cache-Control: no-cache';
    $headers[] = 'Content-Type: application/json';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $result = curl_exec($ch);

    //get curl error and add to order note
    if (curl_errno($ch)) {
        $order->add_order_note(
            sprintf(
                __( 'Lulu API Error: %s', 'woocommerce' ),
                curl_error($ch)
            )
        );
    } else {
        $order->add_order_note(
            sprintf(
                __( 'Lulu API Response: %s', 'woocommerce' ),
                $result
            )
        );
    }

    curl_close($ch);
}
//add action to order is completed
//add_action( 'woocommerce_order_status_completed', 'send_order_to_lulu',10000);
add_action( 'woocommerce_payment_complete', 'send_order_to_lulu' ,10000);


//Adding Lulu shipping method
add_filter( 'woocommerce_shipping_methods', 'register_lulu_method' );

function register_lulu_method( $methods ) {

    // $method contains available shipping methods
    $methods[ 'lulu_method' ] = 'WC_Shipping_Lulu';

    return $methods;
}

//Creating Lulu shipping class
/**
 * WC_Shipping_Lulu class.
 *
 * @class 		WC_Shipping_Lulu
 * @version		1.0.0
 * @package		Shipping-for-WooCommerce/Classes
 * @category	Class
 * @author 		Tyche Softwares
 */
class WC_Shipping_Lulu extends WC_Shipping_Method
{

    /**
     * Constructor. The instance ID is passed to this.
     */
    public function __construct($instance_id = 0)
    {
        $this->id = 'lulu_method';
        $this->instance_id = absint($instance_id);
        $this->title = __('Lulu Shipping Method');
        $this->method_title = __('Lulu Shipping Method');
        $this->method_description = __('Lulu Shipping method.');
        $this->method_flat_price = 35;
        $this->supports = array(
            'shipping-zones',
            'instance-settings',
            'instance-settings-modal'
        );

        $this->instance_form_fields = array(
            'enabled' => array(
                'title' => __('Enable/Disable'),
                'type' => 'checkbox',
                'label' => __('Enable this shipping method'),
                'default' => 'yes',
            ),
            'title' => array(
                'title' => __('Method Title'),
                'type' => 'text',
                'description' => __('This controls the title which the user sees during checkout.'),
                'default' => __('Lulu Shipping Method'),
                'desc_tip' => true
            ),
            'flat_price' => array(
                'title' => __('Flashcard Flat Rate'),
                'type' => 'number',
                'default' => 35,
                'desc_tip' => true
            )
        );

        add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
    }

    /**
     * calculate_shipping function.
     * @param array $package (default: array())
     */
    public function calculate_shipping($package = array())
    {
        $apiResponse = wp_remote_post('https://api.lulu.com/auth/realms/glasstree/protocol/openid-connect/token', array(
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Authorization' => 'Basic MTcxNGQxMDYtNmViYi00Y2I4LTk5M2EtYzY2MGY2ZTcyZWM3OmU0MmIzN2JhLWRjMjctNDBiYi1hODUwLWFkMjlhZjc4NWY2OQ=='
            ),
            'body' => array(
                'grant_type' => 'client_credentials'
            )
        ));

        $bodyResponse = json_decode(wp_remote_retrieve_body($apiResponse));
        $access_token = $bodyResponse->access_token;

        $booksInfo = array(
            39234 => '0850X1100BWSTDPB060UW444MXX',
            39260 => '0850X1100BWSTDPB060UW444MXX',
            39220 => '0850X1100BWSTDPB060UW444MXX',
            39246 => '0850X1100BWSTDPB060UW444MXX',
			39208 => '0850X1100BWSTDPB060UW444MXX',
			43289 => '0850X1100BWSTDPB060UW444MXX',
			43300 => '0850X1100BWSTDPB060UW444MXX',
			43302 => '0827X1169BWSTDPB060UW444MXX'
        );

		$booksPagesCount = array(
            39234 => 116,
            39260 => 226,
            39220 => 232,
			39246 => 208,
			39208 => 492,
			43289 => 256,
			43300 => 328,
			43302 => 734
        );
		
        $pod_package_id = array();
        $plus_flashcard_shipping_value = false;
        $no_book_shipping_value = true;
		$only_virtual_products = 0;
        $products_count = 0;

        foreach ($package['contents'] as $item_id => $values) {
			$products_count++;
            if (in_array(47, $values['data']->category_ids)) {
                $plus_flashcard_shipping_value = true;
            }
			if (in_array(223, $values['data']->category_ids) || in_array(220, $values['data']->category_ids) || in_array(222, $values['data']->category_ids) || in_array(224, $values['data']->category_ids) || in_array(241, $values['data']->category_ids)) {
                $only_virtual_products++;
            }
            $pid = $values['product_id'];
			if($pid == 39208) $multiplyIndex = 2; else $multiplyIndex = 1;
            if (array_key_exists($pid, $booksInfo)) {
                $no_book_shipping_value = false;
                $pod_package_id[] = array(
					"pages_count" => $booksPagesCount[$pid],
					"pid" => $booksInfo[$pid],
					"quantity" => $values['quantity']
				);
				if($pid == 39208){
					$pod_package_id[] = array(
						"pages_count" => 154,
						"pid" => '0850X1100BWSTDPB060UW444MXX',
						"quantity" => $values['quantity']
					);
				}
            }
        }

        if($only_virtual_products == $products_count && $no_book_shipping_value){
            $this->add_rate(array(
                'id' => 'lulu_10000',
                'label' => 'No Shipping Required',
                'cost' => 0
            ));
        }elseif ($no_book_shipping_value && $plus_flashcard_shipping_value) {
            $this->add_rate(array(
                'id' => 'lulu_9999',
                'label' => 'Flat Rate',
                'cost' => $this->get_option('flat_price')
            ));
        } else {

            $shipping_address = array(
				"city" => $package['destination']['city'],
				"country" => $package['destination']['country'],
				"postcode" => $package['destination']['postcode'],
				"state_code" => $package['destination']['state'],
				"street1" => $package['destination']['address_1']
			);
			$line_items = array();
			
			foreach($pod_package_id as $pid){
				$line_items[] = array(
					"page_count" => $pid['pages_count'],
					"pod_package_id" => $pid['pid'],
					"quantity" => $pid['quantity']
				);
			}
			
            $body = array(
				"currency" => "USD",
				"line_items" => $line_items,
				"shipping_address" => $shipping_address
            );

            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, 'https://api.lulu.com/shipping-options');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));

            $headers = array();
            $headers[] = 'Authorization: Bearer ' . $access_token;
            $headers[] = 'Cache-Control: no-cache';
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $result = curl_exec($ch);

            curl_close($ch);

            $results = json_decode($result);

            foreach ($results as $result) {
				if($result->level == 'MAIL') continue;
                if ($plus_flashcard_shipping_value) {
                    $this->add_rate(array(
                        'id' => 'lulu_' . $result->id,
                        'label' => $result->carrier_service_name,
                        'cost' => $result->cost_excl_tax + $this->get_option('flat_price'),
                        'taxes' => '',
                        'calc_tax' => 'per_item',
                        'meta_data' => array(
                            'carrier_service_name' => $result->carrier_service_name,
                            'level' => $result->level
                        )
                    ));
                } else {
                    $this->add_rate(array(
                        'id' => 'lulu_' . $result->id,
                        'label' => $result->carrier_service_name,
                        'cost' => $result->cost_excl_tax,
                        'taxes' => '',
                        'calc_tax' => 'per_item',
                        'meta_data' => array(
                            'carrier_service_name' => $result->carrier_service_name,
                            'level' => $result->level
                        )
                    ));
                }
                //save general metadata for all site
                update_option(str_replace(' ', '_', $result->carrier_service_name), $result->level);
            }
        }
    }
}

/**
 * @snippet       Maxlength @ WooCommerce Checkout Field
 * @how-to        Get CustomizeWoo.com FREE
 * @author        Rodolfo Melogli
 * @testedwith    WooCommerce 4.5
 * @donate $9     https://businessbloomer.com/bloomer-armada/
 */
 
add_filter( 'woocommerce_checkout_fields', 'bbloomer_checkout_fields_custom_attributes', 9999 );
 
function bbloomer_checkout_fields_custom_attributes( $fields ) {
	$fields['billing']['billing_address_1']['maxlength'] = 30;
	$fields['shipping']['shipping_address_1']['maxlength'] = 30;
	
	unset($fields['billing']['billing_address_2']);
    unset($fields['shipping']['shipping_address_2']);
	
	return $fields;
}

/**
 * Exclude products from a particular category on the shop page
 */
function custom_pre_get_posts_query( $q ) {

    //check if page slug is store
    if(!is_shop()) return;
    $tax_query = (array) $q->get( 'tax_query' );

    $tax_query[] = array(
        'taxonomy' => 'product_cat',
        'field' => 'slug',
        'terms' => array( 'pan-canadian-courses' ), // Don't display products in the clothing category on the shop page.
        'operator' => 'NOT IN'
    );


    $q->set( 'tax_query', $tax_query );

}
add_action( 'woocommerce_product_query', 'custom_pre_get_posts_query' );

//send email to emilio.leite@tcmsvc.com
function send_email_about_one_and_done($order_id, $dateTo){
    $order = wc_get_order( $order_id );
    //get student name
    $studentName = $order->get_billing_first_name().' '.$order->get_billing_last_name();

    $dateTo = new DateTime($dateTo, new DateTimeZone('America/Los_Angeles'));
    //set $dateTo to format August 31st, 2023
    $dateTo = $dateTo->format('F jS, Y');

    //get student email
    $to = $order->get_billing_email();

    $subject = 'Thanks for your purchase of the CALE course';

    $body = file_get_contents(__DIR__ .'/emailtemplates/email-body.html');

    $body = str_replace('{{studentName}}', $studentName, $body);

    $body = str_replace('{{dateTo}}', $dateTo, $body);

    $headers = array('Content-Type: text/html; charset=UTF-8');

    wp_mail( $to, $subject, $body, $headers );
    //wp_mail( 'admin@tcmreview.com', $subject, $body, $headers );
    wp_mail( 'emilio.leite@tcmsvc.com', $subject, $body, $headers );
}

function send_email_about_one_and_done_test(){
    //set date from on format August 31st, 2023
    //create date object with date 2023-08-31 23:59 on pacific time
    $dateTo = new DateTime('2023-08-31 23:59', new DateTimeZone('America/Los_Angeles'));
    //set $dateTo to format August 31st, 2023
    $dateTo = $dateTo->format('F jS, Y');

    //set $dateTo to format August 31st, 2023
    //get student name
    $studentName = 'Student Name';

    //get student email
    $to = 'admin@tcmreview.com';

    $subject = 'Thanks for your purchase of the CALE course';
//    $body = '<p>Hi '.$studentName.'</p>
//            <p>Thanks for your purchase of the CALE course. From now until '.$dateTo.', when you purchase the CALE course you receive the NCCAOM course as well.</p>
//            <p><strong>NCCAOM:</strong> The NCCAOM course is on hold until <strong>you ask us to activate it for you.</strong></p>
//            <ul>
//            <li><strong>Want to activate the NCCAOM now?</strong> Respond back to this email and let me know. I’ll get the course activated for you within 24 hours.</li>
//            <li><strong>Want to wait until after you take the CALE?</strong> No problem! Just email admin@tcmreview.com to activate the course within 365 days from the day you purchased the CALE course.</li>
//            <p><strong>Please remember that all courses must be activated within 1 year of the original purchase date to avoid losing access.</strong></strong></p>
//            <p>If you purchased a CALE course + CALE books, the NCCAOM books are included. Your order will only show CALE books. Our books are printed on demand, it may take some time to produce and ship your order. We will keep a close eye on your order and update you with any shipping or tracking information as soon as we receive it.</p>
//            <p>Thanks,</p>
//            <p>TCM Review Student Success Team</p>
//            <p>TCM Review Seminars</p>';

    //call email body from html file
    $body = file_get_contents(__DIR__ .'/emailtemplates/email-body.html');

    $body = str_replace('{{studentName}}', $studentName, $body);

    $body = str_replace('{{dateTo}}', $dateTo, $body);

    $headers = array('Content-Type: text/html; charset=UTF-8');
    //wp_mail( $to, $subject, $body, $headers );
    wp_mail( 'emilio.leite@tcmsvc.com', $subject, $body, $headers );
}

//call send_email_about_one_and_done_test on init
//add_action( 'init', 'send_email_about_one_and_done_test' );
//send_email_about_one_and_done_test();

add_action( 'wp_footer', 'custom_js_tcm' );
function custom_js_tcm() {
    ?>
    <script>
        function saveTest(){
            event.preventDefault();
            window.onbeforeunload = null;
            jQuery('#takeatest').parents('.postrow').html('<div class="loader"></div>');
            window.location.href = 'https://tcmreview.com/tests-2-2/test/';
        }
    </script>
    <style>
        .loader {
            margin: 150px auto;
            border: 16px solid #f3f3f3; /* Light grey */
            border-top: 16px solid #0e65b5; /* Blue */
            border-radius: 50%;
            width: 120px;
            height: 120px;
            animation: spin 2s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
    <?php
}

//add jquery to footer
//add_action( 'wp_footer', 'add_jquery_to_footer' );

function add_jquery_to_footer(){
    ?>
    <script>
        jQuery(document).ready(function(){
            jQuery(document).on("click", ".pum-close.popmake-close", function(){
                //get site domain
                var siteDomain = window.location.hostname;
                //redirect to cart alias
                window.location.href = 'https://'+siteDomain+'/cart/';
            });
			jQuery(document).on("click", ".pum-overlay", function(event){
                //get site domain
				if (jQuery(event.target).closest(".pum-container").length === 0) {
					//get site domain
					var siteDomain = window.location.hostname;
					//redirect to cart alias
					window.location.href = 'https://'+siteDomain+'/cart/';
				}
            });
        });
    </script>
    <?php
}

function custom_jquery_add() {
    //if(is_page('california-acupuncture-board-exam-for-license')) {
        wp_enqueue_script('jquery');
    //}
}
add_action('wp_enqueue_scripts', 'custom_jquery_add' );