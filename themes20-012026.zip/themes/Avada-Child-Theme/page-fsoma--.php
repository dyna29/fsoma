<?php
	/**
	 * Template Name: FSOMA
	 * Description: A custom template for FSOMA.
	 */ 

 
// Initialize WooCommerce session and cart early
if ( ! WC()->session || ! ( WC()->session instanceof WC_Session_Handler ) ) {
    if ( class_exists( 'WC_Session_Handler' ) ) {
        WC()->session = new WC_Session_Handler();
        WC()->session->init();
    }
}
if ( WC()->session && ! WC()->session->has_session() ) {
    WC()->session->set_customer_session_cookie( true );
}
if ( ! WC()->cart ) {
    wc_load_cart();
}

$main_id = get_post_meta( get_the_ID(), '_fsoma_main_product', true );
$other = get_post_meta( get_the_ID(), '_fsoma_other_products', true );

// Auto-add products if not already in cart
function add_product_to_cart_if_not_found( $product_id ) {
    $found = false;
    foreach ( WC()->cart->get_cart() as $item ) {
        if ( (int) $item['product_id'] === (int) $product_id ) {
            $found = true;
            break;
        }
    }
    if ( ! $found ) {
        WC()->cart->add_to_cart( $product_id );
    }
}

if ( $main_id ) {
    add_product_to_cart_if_not_found( $main_id );
}

if ( ! empty( $other ) && is_array( $other ) ) {
    foreach ( $other as $row ) {
        $pid = isset( $row['product'] ) ? (int) $row['product'] : 0;
        if ( $pid ) {
            add_product_to_cart_if_not_found( $pid );
        }
    }
}

// Calculate cart totals upfront to apply discounts immediately
WC()->cart->calculate_totals();

// Function to get discounted price of a product in the cart
function get_orion_discounted_price( $product_id, $quantity = 1, $variation_id = 0, $cart_item_data = array() ) {
    if ( ! WC()->cart ) {
        return false;
    }

    // Backup current cart state for restoration later
    $backup_cart = WC()->cart->get_cart();

    // Empty cart but keep session cookie intact
    WC()->cart->empty_cart( false );

    // Add product temporarily to calculate discount
    $cart_item_key = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, array(), $cart_item_data );
    if ( ! $cart_item_key ) {
        // Restore original cart if add_to_cart fails
        WC()->cart->empty_cart( false );
        foreach ( $backup_cart as $item ) {
            WC()->cart->add_to_cart( $item['product_id'], $item['quantity'], $item['variation_id'] ?? 0, $item['variation'] ?? array(), $item['cart_item_data'] ?? array() );
        }
        WC()->cart->calculate_totals();
        return false;
    }

    // Calculate totals so discount hooks apply
    WC()->cart->calculate_totals();

    // Get cart item with discount applied
    $cart_item = WC()->cart->get_cart_item( $cart_item_key );
    if ( ! $cart_item || ! isset( $cart_item['line_total'] ) ) {
        // Restore cart and return false on error
        WC()->cart->empty_cart( false );
        foreach ( $backup_cart as $item ) {
            WC()->cart->add_to_cart( $item['product_id'], $item['quantity'], $item['variation_id'] ?? 0, $item['variation'] ?? array(), $item['cart_item_data'] ?? array() );
        }
        WC()->cart->calculate_totals();
        return false;
    }

    // Calculate discounted unit price
    $discounted_price = floatval( $cart_item['line_total'] ) / max( 1, intval( $quantity ) );

    // Restore original cart
    WC()->cart->empty_cart( false );
    foreach ( $backup_cart as $item ) {
        WC()->cart->add_to_cart( $item['product_id'], $item['quantity'], $item['variation_id'] ?? 0, $item['variation'] ?? array(), $item['cart_item_data'] ?? array() );
    }
    WC()->cart->calculate_totals();

    return $discounted_price;
}

// Prepare precomputed discounted prices for display
$precomputed = array();
foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
    $product = $cart_item['data'];
    $qty = $cart_item['quantity'];
    $variation_id = $cart_item['variation_id'] ?? 0;
    $cart_item_data = $cart_item['cart_item_data'] ?? array();

    $discounted = get_orion_discounted_price( $product->get_id(), $qty, $variation_id, $cart_item_data );

    $precomputed[ $cart_item_key ] = $discounted !== false ? $discounted : ( $qty ? ( $cart_item['line_total'] / $qty ) : $product->get_price() );
}

// Now use $precomputed prices to render cart items with correct discount prices on first load

?>

<!-- Your HTML goes here -->

<?php foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) :
    $product = $cart_item['data'];
    $qty = $cart_item['quantity'];
    $price_to_show = $precomputed[ $cart_item_key ] ?? $product->get_price();
?>
<div class="cart-item">
    <img src="<?php echo wp_get_attachment_image_url( $product->get_image_id(), 'woocommerce_thumbnail' ); ?>" style="width:80px;height:auto;">
    <h3><?php echo esc_html( $product->get_name() ); ?></h3>
    <p>Price: <?php echo wc_price( $price_to_show ); ?></p>
    <p>Quantity: <?php echo esc_html( $qty ); ?></p>
</div>
<?php endforeach;  

//////////////////////
	exit;
	session_unset();
	    session_destroy();
	if ( ! defined( 'ABSPATH' ) ) {
		exit( 'Direct script access denied.' );
	}
	
	 
	// inside your custom page template (page-fsoma.php) at top before output
	if ( ! class_exists( 'WooCommerce' ) ) {
	    return;
	}
	
	// Ensure WC session exists for guests
	if ( empty( WC()->session ) || ! ( WC()->session instanceof WC_Session_Handler ) ) {
	    if ( class_exists( 'WC_Session_Handler' ) ) {
	        WC()->session = new WC_Session_Handler();
	        WC()->session->init();
	    }
	}
	
	// Ensure session cookie exists
	if ( WC()->session && ! WC()->session->has_session() ) {
	    WC()->session->set_customer_session_cookie( true );
	}
	
	// Ensure cart object exists and totals are calculated
	if ( ! WC()->cart ) {
	    wc_load_cart(); // rarely needed but safe
	}
	
	// Calculate totals so discounts hooked into 'before_calculate_totals' run now
	WC()->cart->calculate_totals();
		//$wad_discounts = wad_get_active_discounts();
	//echo "<pre>";
	   // var_dump($wad_discounts );
	function get_orion_discounted_price( $product_id, $quantity = 1, $variation_id = 0, $cart_item_data = array() ) {
	    if ( ! class_exists( 'WC_Cart' ) || ! WC()->cart ) {
	        return false;
	    }
	 
	    // Backup current cart contents
	    $backup_cart = WC()->cart->get_cart();
	    $backup_cart_totals = array(
	        'contents_total' => WC()->cart->get_cart_contents_total(),
	        'total' => WC()->cart->get_total( 'edit' ),
	    );
	
	 
	    // Remember original session cart hash (just in case)
	    // Clear the cart temporarily
	    WC()->cart->empty_cart( false ); // pass false to avoid destroying session cookie
	
	 
	    // Add product temporarily
	    $cart_item_key = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, array(), $cart_item_data );
	
	    if ( ! $cart_item_key ) {
	        // restore original cart if add_to_cart failed
	        WC()->cart->empty_cart( false );
	        foreach ( $backup_cart as $item ) {
	            WC()->cart->add_to_cart(
	                $item['product_id'],
	                $item['quantity'],
	                isset( $item['variation_id'] ) ? $item['variation_id'] : 0,
	                isset( $item['variation'] ) ? $item['variation'] : array(),
	                isset( $item['cart_item_data'] ) ? $item['cart_item_data'] : array()
	            );
	        }
	        WC()->cart->calculate_totals();
	        return false;
	    }
	
	 
	    // Recalculate totals so Orion discount hooks run
	    WC()->cart->calculate_totals();
	
	    // Retrieve the cart item to get discounted line_total
	    $cart_item = WC()->cart->get_cart_item( $cart_item_key );
	
	    if ( ! $cart_item || ! isset( $cart_item['line_total'] ) ) {
	        // restore and return false
	        WC()->cart->empty_cart( false );
	        foreach ( $backup_cart as $item ) {
	            WC()->cart->add_to_cart(
	                $item['product_id'],
	                $item['quantity'],
	                isset( $item['variation_id'] ) ? $item['variation_id'] : 0,
	                isset( $item['variation'] ) ? $item['variation'] : array(),
	                isset( $item['cart_item_data'] ) ? $item['cart_item_data'] : array()
	            );
	        }
	        WC()->cart->calculate_totals();
	        return false;
	    }
	
	 
	    $discounted_price = floatval( $cart_item['line_total'] ) / max( 1, intval( $quantity ) );
	
	    // Restore original cart
	    WC()->cart->empty_cart( false );
	    foreach ( $backup_cart as $item ) {
	        WC()->cart->add_to_cart(
	            $item['product_id'],
	            $item['quantity'],
	            isset( $item['variation_id'] ) ? $item['variation_id'] : 0,
	            isset( $item['variation'] ) ? $item['variation'] : array(),
	            isset( $item['cart_item_data'] ) ? $item['cart_item_data'] : array()
	        );
	    }
	    WC()->cart->calculate_totals();
	
	 
	    return $discounted_price;
	}
	
	 
	$main_id = get_post_meta( get_the_ID(), '_fsoma_main_product', true );
	$main_desc = get_post_meta( get_the_ID(), '_fsoma_main_description', true );
	$other = get_post_meta( get_the_ID(), '_fsoma_other_products', true );
	$free_desc = get_post_meta( get_the_ID(), '_fsoma_free_product_description', true );
 
			// 🪄 Auto-add a product (optional)
			$product_id = $main_id  ;  // ← replace with your product ID
			$cart       = WC()->cart;
			$found      = false;
			
			foreach ( $cart->get_cart() as $item ) {
			if ( (int) $item['product_id'] === (int) $product_id ) {
				$found = true;
				break;
			}
			}
			//echo "found ". $found;
			if ( ! $found ) {
			$cart->add_to_cart( $product_id ); 
			}

			if ( ! empty($other) && is_array($other) ){ 
				$desc  = array();
				foreach( $other as $row ){
					$pid = isset($row['product']) ? (int)$row['product'] : 0;
					$desc[$pid] = isset($row['description']) ? $row['description'] : '';
					if ( $pid ){
						$cart       = WC()->cart;
						$found      = false;

						foreach ( $cart->get_cart() as $item ) {
							if ( (int) $item['product_id'] === (int) $pid ) {
								$found = true;
								break;
							}
						}

						if ( ! $found ) {
							$cart->add_to_cart( $pid ); 
						}
 

					}  
				}

			}
			   WC()->cart->calculate_totals();
			 
			?>
			 
 
<?php get_header('fsoma'); ?>
<section id="header-banner" style="<?php echo esc_attr( apply_filters( 'awb_content_tag_style', '' ) ); ?>">
	<div class="banner-img"  style="background:url(<?php echo get_stylesheet_directory_uri(); ?>/fsoma-header.jpg)">
	</div>
</section>
 
<section id="caption-banner" class="df-cart-container" style="<?php echo esc_attr( apply_filters( 'awb_content_tag_style', '' ) ); ?>">
	<div class="top-text">
		<ul>
			<li>
				<h3><img src="<?php echo get_stylesheet_directory_uri(); ?>/big-tick.png"> NCCAOM 12 Month Unlimited Access</h3>
			</li>
			<li>
				<span class="actual">$600</span> <span class="offer">$475</span> <span class="save">Save $125</span>
			</li>
		</ul>
	</div>
	<hr>
	<p>Get the same premium access as the 9-month plan, but with 12 full months of unlimited access</p>
</section>
<section id="features" style="<?php echo esc_attr( apply_filters( 'awb_content_tag_style', '' ) ); ?>">
	<ul class="features">
		<li>
			<div class="feature-block block-1">
				<span class="icon-holder"><img src="<?php echo get_stylesheet_directory_uri(); ?>/user-circle-check.png"></span>
				<h3>Verified Members Only</h3>
				<p>Exclusive pricing for FSOMA members</p>
			</div>
		</li>
		<li>
			<div class="feature-block block-2">
				<span class="icon-holder"><img src="<?php echo get_stylesheet_directory_uri(); ?>/medal.png"></span>
				<h3>Premium Content</h3>
				<p>Full access to all course materials</p>
			</div>
		</li>
		<li>
			<div class="feature-block block-3">
				<span class="icon-holder"><img src="<?php echo get_stylesheet_directory_uri(); ?>/folder-simple-plus.png"></span>
				<h3>Optional Add-ons</h3>
				<p>Customize with textbooks & flashcards</p>
			</div>
		</li>
	</ul>
</section>
<section id="product-login-fsoma" style="<?php echo esc_attr( apply_filters( 'awb_content_tag_style', '' ) ); ?>">
	<div class="fsoma-cart">
		
		<div class="df-cart-container">
			<?php if ( $cart->is_empty() ) : ?>
			<?php else : ?>
			<div class="df-cart-table">
				<ul class="product-list">
					<?php 
                    $countfree = 0;
                    foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) :
						$product = $cart_item['data'];
						$qty     = $cart_item['quantity'];
						                     if($main_id == $product->id || $product->get_price() ==0 ) {
						?>
					<li data-key="<?php echo esc_attr( $cart_item_key ); ?>">
						<div class="product">
							<div class="product-image">
								<?php echo $product->get_image( 'woocommerce_thumbnail', [ 'style' => 'width:80px;height:auto;' ] ); ?>
							</div>
							<div class="product-info">
								<span class="name"><?php echo esc_html( $product->get_name() ); ?></span>
								<?php if($product->id == $main_id) { ?>
								<span class="desc"><?php echo esc_html( $main_desc ); ?></span>
								<?php } ?>
								<?php  if($product->get_price() ==0){?>
								<span class="desc"><?php echo esc_html( $free_desc ); ?></span>
								<?php } ?>
								<?php 
									if($product->get_price() !=0){
									    ?>
								<div class="qty-controls">
									<button class="minus">−</button>
									<input type="number" value="<?php echo esc_attr( $qty ); ?>" min="0">
									<button class="plus">+</button>
								</div>
								<?php } ?>
							</div>
							<div class="product-price">
								<?php 
									if($product->get_price() ==0){
									    ?>
								<span class="salefree">FREE</span>
								<?php
									}else{
									    ?>
								<?php
									if ( $product->is_on_sale() ) : 
									?>
								<span class="regular"><s><?php echo wc_price( $product->get_regular_price() ); ?></s></span>
								<span class="sale"><?php echo wc_price( $product->get_sale_price() ); ?></span>
								<?php else : ?>
								<span class="sale"><?php echo wc_price( $product->get_price() ); ?></span>
								<?php endif;
									}
									?>
							</div>
						</div>
					</li>
					<?php 
						}
						endforeach; ?>
				</ul>
				<h4>You can remove optional textbooks and flashcards if you already own them.</h4>
				<ul class="product-list others">
					<?php 
						if ( ! empty($other) && is_array($other) ){ 
					 
						
						    	$cart = WC()->cart;
						
						// 1) Precompute discounted prices for each cart item (safe — we mutate cart but not while iterating)
						$precomputed = array();
						
						foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
						    $product_id   = isset( $cart_item['product_id'] ) ? $cart_item['product_id'] : 0;
						    $variation_id = isset( $cart_item['variation_id'] ) ? $cart_item['variation_id'] : 0;
						    $qty          = isset( $cart_item['quantity'] ) ? $cart_item['quantity'] : 1;
						
						    // This will temporarily clear cart and restore — do it now (outside rendering)
						    $discounted = get_orion_discounted_price( $product_id, $qty, $variation_id, isset($cart_item['cart_item_data']) ? $cart_item['cart_item_data'] : array() );
						 
						 // echo "<br>------new-------<br>"; var_dump( $discounted);
						 // echo "<br>---------------<br>";
						    $precomputed[ $cart_item_key ] = $discounted;
						}
						        ?>
					<?php foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) :
						$product = $cart_item['data'];
						$qty     = $cart_item['quantity'];
						$line_subtotal     = $cart_item['line_subtotal'];      
						$line_total        = $cart_item['line_total'];    
						// Use the precomputed discounted price (if available), otherwise fallback to line_total/qty
						$discounted_unit = isset( $precomputed[ $cart_item_key ] ) && $precomputed[ $cart_item_key ] !== false
						 ? $precomputed[ $cart_item_key ]
						 : ( $qty ? ( $line_total / $qty ) : $product->get_price() );
						// echo "<br>---------------<br>";
						//echo   $discounted_unit ;
						                       if($main_id != $product->id && $product->get_price() !=0 ) { 
						?>
					<li data-key="<?php echo esc_attr( $cart_item_key ); ?>">
						<div class="product">
							<div class="product-image">
								<?php echo $product->get_image( 'woocommerce_thumbnail', [ 'style' => 'width:80px;height:auto;' ] ); ?>
							</div>
							<div class="product-info">
								<span class="name"><?php echo esc_html( $product->get_name() ); ?></span>
								<span class="desc"><?php echo esc_html(  $desc[$pid] ); ?></span>
								<div class="qty-controls">
									<button class="minus">−</button>
									<input type="number" value="<?php echo esc_attr( $qty ); ?>" min="0">
									<button class="plus">+</button>
								</div>
							</div>
							<div class="product-price">
								<button class="remove"><img src="<?php echo get_stylesheet_directory_uri(); ?>/delete-product.png"></button>
								<?php
									?>
								<div class="price-block">
									<span class="regular"><s><?php echo wc_price( $product->get_regular_price() ); ?></s></span>
									<span class="sale"><?php echo wc_price( $discounted_unit )  ; ?></span>
								</div>
								<?php  
									?>
							</div>
						</div>
					</li>
					<?php
						}
						endforeach; ?>
					<?php }  ?>
				</ul>

               <?php
/** 
 * Custom Shipping Methods Layout – Single File Version
 * Paste inside your custom cart template or cart-shipping.php override
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$packages = WC()->shipping()->get_packages();
$package  = reset( $packages );
$package_index = 0;
$chosen_method = WC()->session->get( 'chosen_shipping_methods' )[ $package_index ] ?? '';
?>

<style>
/* --- Layout Wrapper --- */
.shipping-row{
  display: grid;
  grid-template-columns: 160px 1fr;
  gap: 10px;
  align-items: start;
  margin: 20px 0;
  font-family: Arial, sans-serif;
  color: #333;
}

/* --- "Shipping" label --- */
.shipping-label{
  font-weight: 600;
  padding-top: 6px;
}

/* --- Shipping Options Container --- */
.ship-option{
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 6px;
  margin-bottom: 10px;
  border-radius: 4px;
}

.ship-option input[type="radio"]{
  margin-right: 8px;
}

.ship-name{
  flex: 1;
  margin-left: 6px;
}

.ship-price{
  flex: 0;
  font-weight: 600;
}

/* Mobile layout */
@media (max-width: 600px){
  .shipping-row{
    grid-template-columns: 1fr;
  }
  .shipping-label{
    padding-bottom: 8px;
  }
  .ship-option{
    justify-content: flex-start;
    gap: 10px;
  }
}
</style>

<!-- HTML + PHP -->

 



				<!--<tfoot>
					<tr>
						<td colspan="3" style="text-align:right;"><strong>Total:</strong></td>
						<td id="cart-total"><strong><?php echo wc_price( $cart->get_total( 'edit' ) ); ?></strong></td>
						<td></td>
					</tr>
					</tfoot>-->
			</div>
			<!--<a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="checkout-btn">Proceed to Checkout</a> -->
			<?php endif; ?>
		</div>
		<?php
			// JS + styling
			$ajax = admin_url( 'admin-ajax.php' );
			$nonce = wp_create_nonce( 'df-cart-nonce' );
			?> 
	</div>
	<div class="fsoma-membership-pay">
		<div class="fsoma-membership-validate df-cart-container">
			<h4><img src="<?php echo get_stylesheet_directory_uri(); ?>/svg-shield.png">FSOMA Member Verification</h4>
			<p>Enter your FSOMA Member ID to access this exclusive pricing</p>
			<input type="text" class="memberid" name="memberid">
			<a href="javascript:void(0)" class="membership-verify"><img src="<?php echo get_stylesheet_directory_uri(); ?>/svg-v.png">Verify Membership</a>
		</div>
		<div class="fsoma-order-summary df-cart-container">
			<h4>Order Summary</h4>
               <?php if ( WC()->cart ) : ?>
			<div class="order-summary">
				<ul class="order-summary-row">
					<li>Subtotal</li>
					<li><?php wc_cart_totals_subtotal_html(); ?></li>
				</ul>
				<ul class="order-summary-row">
					<li>Shipping</li>
					<li class="sum-free">FREE</li>
				</ul>
              <ul class="order-summary-row shipping-options">
 <li>
 
    <form id="custom-shipping-form">

      <?php if ( ! empty( $package['rates'] ) ) : ?>
        <?php foreach ( $package['rates'] as $rate_id => $rate ) : ?>
          
          <?php
            $checked = $rate_id === $chosen_method ? 'checked' : '';
            $price   = wc_price( $rate->get_cost() + array_sum( $rate->get_taxes() ?: [] ) );
          ?>
<li>
          <label class="ship-option">
            <input type="radio" 
              name="shipping_method[<?php echo $package_index; ?>]" 
              value="<?php echo esc_attr( $rate_id ); ?>" 
              <?php echo $checked; ?>>
             </label></li><li>
            <span class="ship-name"><?php echo esc_html( $rate->get_label() ); ?></span>
            <span class="ship-price"><?php echo $price; ?></span></li>
         

        <?php endforeach; ?>

      <?php else: ?>
        <p>No shipping methods found.</p>
      <?php endif; ?>

    </form>
   
</ul>
				<ul class="order-summary-row">
					<li>Tax (8.75%)</li>
					<li>$93.84</li>
				</ul>
				<ul class="order-summary-row">
					<li >Total</li>
					<li class="total"><?php wc_cart_totals_order_total_html(); ?></li>
				</ul>
			</div>
            <?php endif; ?>
			<a href="javascript:void(0)" class="verify-tocontinue">Verify Membership to Continue</a>
		</div>
	</div>
</section>
<?php
	do_action( 'avada_after_content' ); ?>
<?php get_footer(); ?>
<script>document.addEventListener('click', async e => {
	if (e.target.closest('.plus') || e.target.closest('.minus') || e.target.closest('.remove')) {
	
		// ✅ Changed 'tr[data-key]' to '[data-key]' — works for div, li, etc.
		const row = e.target.closest('[data-key]');
		const input = row.querySelector('input[type="number"]');
		let qty = parseInt(input.value, 10);
	
		if (e.target.closest('.plus')) qty++;
		if (e.target.closest('.minus')) qty--;
		if (e.target.closest('.remove')) qty = 0;
	
		qty = Math.max(0, qty);
		input.value = qty;
	
		const data = new URLSearchParams({
			action: 'df_update_cart_qty',
			nonce: '<?php echo esc_js($nonce); ?>',
			cart_item_key: row.dataset.key,
			qty
		});
	
		const res = await fetch('<?php echo esc_url($ajax); ?>', {
			method: 'POST',
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			body: data
		});
	
		const json = await res.json();
	
		if (json.success) {
			if (qty <= 0) row.remove();
			else row.querySelector('.subtotal').innerHTML = json.data.line_subtotal;
			document.getElementById('cart-total').innerHTML = '<strong>' + json.data.cart_total + '</strong>';
			if (json.data.cart_count === 0) document.querySelector('.df-cart-container').innerHTML = '<p>Your cart is empty.</p>';
		} else {
			alert(json.data?.message || 'Error updating cart');
		}
	}
	});
	
</script>
<script>
	jQuery(function($){
	    $(document).on('click', '.membership-verify', function(e){
	        e.preventDefault();
	
	        var $btn = $(this);
	        var memberid = $.trim( $('.memberid').val() );
	
	        if ( memberid === '' ) {
	            alert('Please enter membership id');
	            return;
	        }
	
	        $btn.prop('disabled', true).addClass('loading');
	
	        $.post( '<?php  echo admin_url( 'admin-ajax.php' );?>', {
	            action: 'fs_verify_member',
	            memberid: memberid,
	            nonce: '<?php  echo wp_create_nonce( 'fs_member_verify_nonce' );?>'
	        })
	        .done(function(resp){
	            if ( resp && resp.success ) {
	                // verified
	                alert( resp.data.message || 'Verified' );
	                // Optionally do UI updates — show verified text, redirect, etc.
	                $btn.closest('form, .membership-block').find('.verify-result').remove();
	                $btn.after('<span class="verify-result" style="color:green;margin-left:8px;">Verified</span>');
	            } else {
	                var msg = ( resp && resp.data && resp.data.message ) ? resp.data.message : 'Verification failed';
	                alert( msg );
	                $btn.closest('form, .membership-block').find('.verify-result').remove();
	                $btn.after('<span class="verify-result" style="color:red;margin-left:8px;">' + msg + '</span>');
	            }
	        })
	        .fail(function(xhr, status){
	            alert('Request failed: ' + status);
	        })
	        .always(function(){
	            $btn.prop('disabled', false).removeClass('loading');
	        });
	    });
	});
</script>