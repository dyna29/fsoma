<?php
	/**
	 * Template Name: FSOMA
	 * Description: A custom template for FSOMA.
	 */ 
  get_header('fsoma'); 
	
	session_unset();
	    session_destroy();
	if ( ! defined( 'ABSPATH' ) ) {
		exit( 'Direct script access denied.' );
	}
	
	 
	// inside your custom page template (page-fsoma.php) at top before output
	if ( ! class_exists( 'WooCommerce' ) ) {
	    return;
	}
	
	// Ensure WC session exists for guests
 
	add_action( 'init', function() {
    if ( class_exists( 'WC_Session_Handler' ) && ! WC()->session ) {
        WC()->session = new WC_Session_Handler();
        WC()->session->init();
    }
});
	// Ensure session cookie exists
	if ( WC()->session && ! WC()->session->has_session() ) {
	    WC()->session->set_customer_session_cookie( true );
	}
	
	// Ensure cart object exists and totals are calculated
	if ( ! WC()->cart ) {
	    wc_load_cart(); // rarely needed but safe
	}
		$main_id = get_post_meta( get_the_ID(), '_fsoma_main_product', true );
	$main_desc = get_post_meta( get_the_ID(), '_fsoma_main_description', true );
	$other = get_post_meta( get_the_ID(), '_fsoma_other_products', true );
	$free_desc = get_post_meta( get_the_ID(), '_fsoma_free_product_description', true ); 
		//$wad_discounts = wad_get_active_discounts();
 //
	 

 
			// 🪄 Auto-add a product (optional)
			$product_id = $main_id  ;  // ← replace with your product ID
			$cart       = WC()->cart;
			$found      = false;
			//echo "<pre>"; 
			 
			if (  (WC()->cart->is_empty() )) {

				echo "inside";
			foreach ( $cart->get_cart() as $item ) {
			if ( (int) $item['product_id'] === (int) $product_id ) {
				$found = true;
				break;
			}
			}
			//echo "found ". $found;
			if ( ! $found ) {
			$cart->add_to_cart( $product_id ); 
			//echo "<br>=====MAIN=======";
			//print_r($cart->get_cart());
			}
	
			if ( ! empty($other) && is_array($other) ){ 
				$desc  = array();
				foreach( $other as $row ){
					$pid = isset($row['product']) ? (int)$row['product'] : 0;
					$desc[$pid] = isset($row['description']) ? $row['description'] : '';
					if ( $pid ){
						//$cart       = WC()->cart;
						$found      = false;

						foreach ( $cart->get_cart() as $item ) {
							if ( (int) $item['product_id'] === (int) $pid ) {
								$found = true;
								break;
							}
						}

						if ( ! $found ) {
							$cart->add_to_cart( $pid ); 
							//echo "<br>=====OTHER=======";
							//print_r($cart->get_cart());
						}
 

					}  
				}

			} 
}
			   WC()->cart->calculate_totals();
		//}
			 
			
//exit();			
			?>
			 
 <style>
	.product {
    display: flex;
}
.product-image {
    flex: 0 0 auto;
}
.product-info {
    flex: 1;
}
.product-price {
    flex: 0 0 auto;
    text-align: right;
}
	</style>

<section id="header-banner" style="<?php echo esc_attr( apply_filters( 'awb_content_tag_style', '' ) ); ?>">
	<div class="banner-img"  style="background:url(<?php echo get_stylesheet_directory_uri(); ?>/fsoma-header.jpg)">
	</div>
</section>
 
<section id="caption-banner" class="df-cart-container" style="<?php echo esc_attr( apply_filters( 'awb_content_tag_style', '' ) ); ?>">
	<div class="top-text">
		<ul>
			<li>
				<h3><img src="<?php echo get_stylesheet_directory_uri(); ?>/big-tick.png"> NCCAOM 12 Month Unlimited Access</h3>
			</li>
			<li>
				<span class="actual">$600</span> <span class="offer">$475</span> <span class="save">Save $125</span>
			</li>
		</ul>
	</div>
	<hr>
	<p>Get the same premium access as the 9-month plan, but with 12 full months of unlimited access</p>
</section>
<section id="features" style="<?php echo esc_attr( apply_filters( 'awb_content_tag_style', '' ) ); ?>">
	<ul class="features">
		<li>
			<div class="feature-block block-1">
				<span class="icon-holder"><img src="<?php echo get_stylesheet_directory_uri(); ?>/user-circle-check.png"></span>
				<h3>Verified Members Only</h3>
				<p>Exclusive pricing for FSOMA members</p>
			</div>
		</li>
		<li>
			<div class="feature-block block-2">
				<span class="icon-holder"><img src="<?php echo get_stylesheet_directory_uri(); ?>/medal.png"></span>
				<h3>Premium Content</h3>
				<p>Full access to all course materials</p>
			</div>
		</li>
		<li>
			<div class="feature-block block-3">
				<span class="icon-holder"><img src="<?php echo get_stylesheet_directory_uri(); ?>/folder-simple-plus.png"></span>
				<h3>Optional Add-ons</h3>
				<p>Customize with textbooks & flashcards</p>
			</div>
		</li>
	</ul>
</section>
<section id="product-login-fsoma" style="<?php echo esc_attr( apply_filters( 'awb_content_tag_style', '' ) ); ?>">
	<div class="fsoma-cart">
		
		<div class="df-cart-container">
			<?php if ( $cart->is_empty() ) : ?>
			<?php else : ?>
			<div class="df-cart-table">
				<ul class="product-list">
					<?php 
                    $countfree = 0;
                    foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) :
						$product = $cart_item['data'];
						$qty     = $cart_item['quantity'];
						                     if($main_id == $product->id || $product->get_price() ==0 ) {
						?>
					<li data-key="<?php echo esc_attr( $cart_item_key ); ?>">
						<div class=" mainproduct">
							<div class="product-image">
								<?php echo $product->get_image( 'woocommerce_thumbnail', [ 'style' => 'width:80px;height:auto;' ] ); ?>
							</div>
							<div class="product-info">
								<span class="name"><?php echo esc_html( $product->get_name() ); ?></span>
								<?php if($product->id == $main_id) { ?>
								<span class="desc"><?php echo esc_html( $main_desc ); ?></span>
								<?php } ?>
								<?php  if($product->get_price() ==0){?>
								<span class="desc"><?php echo esc_html( $free_desc ); ?></span>
								<?php } ?>
								<?php 
									if($product->get_price() !=0){
									    ?>
								<div class="qty-controls"> Quantity: 1 </div>
								<?php } ?>
							</div>
							<div class="product-price main-product">
								<?php 
									if($product->get_price() ==0){
									    ?>
								<span class="salefree">FREE</span>
								<?php
									}else{
									    ?>
								<?php
									if ( $product->is_on_sale() ) : 
									?>
								<span class="regular"><s><?php echo wc_price( $product->get_regular_price() ); ?></s></span>
								<span class="sale"><?php echo wc_price( $product->get_sale_price() ); ?></span>
								<?php else : ?>
								<span class="sale"><?php echo wc_price( $product->get_price() ); ?></span>
								<?php endif;
									}
									?>
							</div>
						</div>
					</li>
					<?php 
						}
						endforeach; ?>
				</ul>
				<h4>You can remove optional textbooks and flashcards if you already own them.</h4>
				<ul class="product-list others">
					<?php 

					$otherproductsincart = array();
						if ( ! empty($other) && is_array($other) ){ 
					 
						
						    	$cart = WC()->cart;
						
						// 1) Precompute discounted prices for each cart item (safe — we mutate cart but not while iterating)
					  foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) :
						$otherproductsincart[] = $product->id;
				 			$product = $cart_item['data'];
						$qty     = $cart_item['quantity'];
						 
						                       if($main_id != $product->id && $product->get_price() !=0 ) { 
												$pid = $product->id;
						?>
					<li data-key="<?php echo esc_attr( $cart_item_key ); ?>" data-id="<?php echo esc_attr($pid); ?>">
						<div class="product">
							<div class="product-image">
								<?php echo $product->get_image( 'woocommerce_thumbnail', [ 'style' => 'width:80px;height:auto;' ] ); ?>
							</div>
							<div class="product-info">
								<span class="name"><?php echo esc_html( $product->get_name() ); ?></span>
								<span class="desc"><?php echo esc_html(  $desc[$pid] ); ?></span>
									<div class="qty-controls">
									<button class="minus" pid = "<?php echo $pid;?>">−</button>
									<input type="number"  class="product-qty" value="<?php echo esc_attr( $qty ); ?>" min="0">
									<button class="plus" pid = "<?php echo $pid;?>">+</button>
								</div>
							</div>
							<div class="product-price">
								<button class="remove" pid = "<?php echo $pid;?>"><img src="<?php echo get_stylesheet_directory_uri(); ?>/delete-product.png"></button>
							
								<?php
									?>
								<div class="price-block">
									<span class="regular"><s><?php echo wc_price( $product->get_regular_price() ); ?></s></span>
									<span class="sale"><?php echo wc_price( $product->get_sale_price() ); ?></span>
								</div>
								<?php  
									?>
							</div>
						</div>
					</li>
					<?php
						}
						endforeach; ?>
					<?php 
				foreach( $other as $row ){


						$pid = isset($row['product']) ? (int)$row['product'] : 0;
						$toaddactive = "";
					if(!(in_array($pid,$otherproductsincart))){
                            $toaddactive = "active";
					}
							$product = wc_get_product( $pid );
                         $image_url = wp_get_attachment_image_url( $product->get_image_id(), 'full' );

						 ?>
						 <li class="addproduct <?php echo $toaddactive;?>" id="addproduct-<?php echo $pid; ?>">
						<div class="product">
						<div class="product-image">
    <?php  
    echo '<img src="' . esc_url( $image_url ) . '" style="width:80px;height:auto;" />';
    ?>
</div>

<?php 
$product = wc_get_product( $pid );
$qty     = WC()->cart ? WC()->cart->get_cart_item_quantities()[ $pid ] ?? 0 : 0;

// Short description (excerpt)
$short_desc = wp_strip_all_tags( $product->get_short_description() );
?>

<div class="product-info">
    <span class="name"><?php echo esc_html( $product->get_name() ); ?></span>

    <span class="desc">
      <?php echo esc_html(  $desc[$pid] ); ?>
    </span>

    <div class="qty-controls">
        <button class="minus" pid = "<?php echo $pid;?>">−</button>
        <input type="number"  class="product-qty" value="<?php echo esc_attr( $qty ); ?>" min="0">
        <button class="plus" pid = "<?php echo $pid;?>">+</button>
    </div>
</div>

<div class="product-price">
 

    <button class="add">
        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/add-product.png' ); ?>" pid = "<?php echo $pid;?>">
    </button>

    <div class="price-block">
        <?php if ( $product->is_on_sale() ) : ?>
            <span class="regular"><s><?php echo wc_price( $product->get_regular_price() ); ?></s></span>
            <span class="sale"><?php echo wc_price( $product->get_sale_price() ); ?></span>
        <?php else : ?>
            <span class="sale"><?php echo wc_price( $product->get_price() ); ?></span>
        <?php endif; ?>
    </div>
</div>
</div>
		</li>

						 <?php
				}
				
				}  ?>
				</ul>

               <?php
/** 
 * Custom Shipping Methods Layout – Single File Version
 * Paste inside your custom cart template or cart-shipping.php override
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$packages = WC()->shipping()->get_packages();
$package  = reset( $packages );
$package_index = 0;
$chosen_method = WC()->session->get( 'chosen_shipping_methods' )[ $package_index ] ?? '';
?>

 
<!-- HTML + PHP -->

 



				<!--<tfoot>
					<tr>
						<td colspan="3" style="text-align:right;"><strong>Total:</strong></td>
						<td id="cart-total"><strong><?php echo wc_price( $cart->get_total( 'edit' ) ); ?></strong></td>
						<td></td>
					</tr>
					</tfoot>-->
			</div>
			<!--<a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="checkout-btn">Proceed to Checkout</a> -->
			<?php endif; ?>
		</div>
 
	</div>
	<div class="fsoma-membership-pay">
		<!--<div class="fsoma-membership-validate df-cart-container">
			<h4><img src="<?php echo get_stylesheet_directory_uri(); ?>/svg-shield.png">FSOMA Member Verification</h4>
			<p>Enter your FSOMA Member ID to access this exclusive pricing</p>
			<input type="text" class="memberid" name="memberid">
			<a href="javascript:void(0)" class="membership-verify"><img src="<?php echo get_stylesheet_directory_uri(); ?>/svg-v.png">Verify Membership</a>
		</div>-->
		<div class="fsoma-order-summary df-cart-container">
			<h4>Order Summary</h4>
               <?php if ( WC()->cart ) : ?>
			<div class="order-summary">
				<ul class="order-summary-row">
					<li>Subtotal</li>
					<li id="cart-subtotal"></li>
				</ul>
				 
          
				<ul class="order-summary-row">
					<li><?php $standard_rates = WC_Tax::get_rates( '' ); // empty string = Standard Rates

foreach ( $standard_rates as $rate_id => $rate ) {
    echo $rate['label'];  // This is the tax name
}?>  </li>
					<li id="cart-tax">  </li>
				</ul>
			 
				<ul class="order-summary-row">
					<li >Total</li>
					<li id="cart-total"><?php echo wc_price( $amount ); ?></li>
				</ul>
			</div>
			
			<span class="note">*Shipping calculated at checkout.</span>
            <?php endif; ?>
			<a href="<?php echo wc_get_checkout_url(); ?>" class="verify-tocontinue">Verify Membership to Continue</a>


			
		</div>
	</div>
</section>
<?php
	do_action( 'avada_after_content' ); ?>
<?php get_footer(); ?>
<script>document.addEventListener('click', async e => {
	if (e.target.closest('.plus') || e.target.closest('.minus') || e.target.closest('.remove')) {
	
		// ✅ Changed 'tr[data-key]' to '[data-key]' — works for div, li, etc.
		const row = e.target.closest('[data-key]');
		const datapid = e.target.closest('[data-id]');
		const input = row.querySelector('input[type="number"]');

		let pid = datapid.dataset.id
		let qty = parseInt(input.value, 10);
	
		if (e.target.closest('.plus')) qty++;
		if (e.target.closest('.minus')) qty--;
		if (e.target.closest('.remove')) qty = 0;
	 
		qty = Math.max(0, qty);
		input.value = qty;
	
		const data = new URLSearchParams({
			action: 'df_update_cart_qty',
			nonce: my_wc_ajax.nonce,
			cart_item_key: row.dataset.key,
			qty
		});
	
		const res = await fetch(my_wc_ajax.ajax_url, {
			method: 'POST',
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			body: data
		});
	
		const json = await res.json();
	
		if (json.success) { 
			if (qty <= 0)
				{
					row.remove(); 
					document.getElementById("addproduct-" + pid)?.classList.add("active");
					document.getElementById("addproduct-" + pid).querySelector("input").value = 0
				} 
			else{
 row.querySelector('.subtotal').innerHTML = json.data.line_subtotal;
			}
			 
		calculateTotals()
		} else {
			alert(json.data?.message || 'Error updating cart');
		}
			
	}

	    let btn = e.target.closest('.add');
    if (!btn) return;

    // click may be on <img>, so use the image's pid
    let pid = btn.querySelector('[pid]').getAttribute('pid');

    addProductToCart(pid);


	});

 

function addProductToCart(pid) {

    let formData = new FormData();
    formData.append('action', 'df_add_to_cart');
    formData.append('product_id', pid);

    fetch(wc_add_to_cart_params.ajax_url, {
        method: 'POST',
        credentials: 'same-origin',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        console.log(data);

        if (data.success) {
            // Refresh cart fragments
              let html = data.data.html; // the <li> received from PHP

        // Convert HTML → DOM <li>
        let temp = document.createElement('ul'); // safe container
        temp.innerHTML = html.trim();
        let newLi = temp.firstElementChild;

        // Target <li> where new item should be inserted before
        let targetLi = document.getElementById('addproduct-' + pid);

        if (targetLi && targetLi.parentNode) {
            targetLi.parentNode.insertBefore(newLi, targetLi);
				document.getElementById("addproduct-" + pid)?.classList.remove("active");
        } else {
            console.warn('Target #addproduct-' + pid + ' not found');
        }
	calculateTotals()
        // Update cart fragments
        document.body.dispatchEvent(new Event('wc_fragment_refresh'));
        }
    });
	
}
function calculateTotals() {
    let subtotal = 0;

    document.querySelectorAll(".product-qty").forEach(function (qtyInput) {
        let qty = parseFloat(qtyInput.value) || 0;
        let productDiv = qtyInput.closest(".product");

        // Read price from the product HTML
        let price = getProductPrice(productDiv);
console.log("price"+price)
        subtotal += qty * price;
    });
	let mainproductDiv = document.querySelector('.mainproduct');
subtotal = getMainProductPrice(mainproductDiv) + subtotal
    // TAX (fixed example)
    let tax = 7.20;  // replace with your dynamic tax if needed

    let total = subtotal + tax;

    // Update values
	console.log( "subtotal"+subtotal.toFixed(2))
	console.log( "tax"+tax.toFixed(2))
	console.log( "total"+total.toFixed(2))
    document.getElementById("subtotal").innerText = subtotal.toFixed(2);
    document.getElementById("tax").innerText = tax.toFixed(2);
    document.getElementById("total").innerText = total.toFixed(2);
}
function getProductPrice(productElement) {
    // Try: sale price first
    let saleEl = productElement.querySelector(".sale .amount");
 

 
    // Remove currency symbol span and get only the price number
    let number = saleEl.childNodes[1].textContent.trim();
    let price = parseFloat(number);
  
  if(price==""){
  // Fallback: regular price
    let regEl = productElement.querySelector(".regular .amount");

   // Remove currency symbol span and get only the price number
    let number = regEl.childNodes[1].textContent.trim();
    let price = parseFloat(number);
    return price;

  }else{
	    return price;
  }
  
    return 0;
}

function getMainProductPrice(productElement) {

    

    // 2️⃣ SALE price (preferred)
    let saleEl = productElement.querySelector(".sale");
    if (saleEl) {
        return extractPrice(saleEl);
    }

    // 3️⃣ REGULAR price (fallback)
    let regularEl = productElement.querySelector(".regular");
    if (regularEl) {
        return extractPrice(regularEl);
    }

    return 0;
}
function extractPrice(el) {
    let text = el.innerText
        .replace(/[^0-9.,]/g, "") // remove USD $, commas, symbols
        .trim();

    return parseFloat(text) || 0;
}
 
  function calculateTotals(event) { 
    const formData = new FormData();
    formData.append('action', 'get_cart_totals');

    fetch(wc_add_to_cart_params.ajax_url, {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(response => {
        if (!response.success) {
            console.error("Error:", response);
            return;
        }

        const data = response.data;
        console.log("Subtotal:", data.subtotal);
        console.log("Tax:", data.tax);
        console.log("Total:", data.total);

        // example DOM updates
        document.querySelector('#cart-subtotal').innerHTML = data.subtotal;
        document.querySelector('#cart-tax').innerHTML = data.tax;
        document.querySelector('#cart-total').innerHTML = data.total;
    })
    .catch(err => console.error("AJAX failed:", err));
}

calculateTotals()
</script>