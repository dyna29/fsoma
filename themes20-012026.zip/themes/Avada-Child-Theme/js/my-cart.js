jQuery(function($){
  $('#custom-shipping-form').on('change', 'input[type=radio]', function(){

    var method = $(this).val();
    var pkgIndex = 0; // package index

    $.post(my_wc_ajax.update_shipping_url, {
      shipping_method: method, 
      security: my_wc_ajax.security
    }, function(resp){
      // resp should indicate success; refresh totals or fragments
      location.reload();
    });
  });
});
