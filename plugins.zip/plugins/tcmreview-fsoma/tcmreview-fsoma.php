<?php
/**
 * Plugin Name: TCMReview FSOMA
 * Description: is a custom integration plugin designed for FSOMA Promotions. It enables secure communication between your WordPress website and the FSOMA server, allowing the system to generate, validate, and manage student promotion tokens.
 */

function tcmreview_create_token_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'tcmreview_tokens';
    $charset_collate = $wpdb->get_charset_collate();

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

    $sql = "CREATE TABLE $table_name (
        id int NOT NULL AUTO_INCREMENT,
        user_id int NOT NULL,
        token text NOT NULL,
        token_generated datetime NOT NULL,
        expiry_date datetime NOT NULL,

        user_email varchar(255) NOT NULL,
        user_phone varchar(50) NOT NULL,

        billing_first_name varchar(200) NOT NULL,
        billing_last_name varchar(200) NOT NULL,
        billing_company varchar(200) DEFAULT NULL,
        billing_address_1 varchar(255) NOT NULL,
        billing_address_2 varchar(255) DEFAULT NULL,
        billing_city varchar(200) NOT NULL,
        billing_state varchar(200) NOT NULL,
        billing_postcode varchar(50) NOT NULL,
        billing_country varchar(100) NOT NULL,
        billing_phone varchar(50) DEFAULT NULL,
        billing_email varchar(255) DEFAULT NULL,

        shipping_first_name varchar(200) DEFAULT NULL,
        shipping_last_name varchar(200) DEFAULT NULL,
        shipping_company varchar(200) DEFAULT NULL,
        shipping_address_1 varchar(255) DEFAULT NULL,
        shipping_address_2 varchar(255) DEFAULT NULL,
        shipping_city varchar(200) DEFAULT NULL,
        shipping_state varchar(200) DEFAULT NULL,
        shipping_postcode varchar(50) DEFAULT NULL,
        shipping_country varchar(100) DEFAULT NULL,
        shipping_phone varchar(50) DEFAULT NULL,

        PRIMARY KEY  (id)
    ) $charset_collate;";

    dbDelta( $sql );
}

register_activation_hook( __FILE__, 'tcmreview_create_token_table' );


/**
 * Register REST route
 *
 * POST /wp-json/fsoma/v1/generate-token
 * body: { "token": "<token-string>", "user_id": 123 }  // user_id optional
 */
add_action( 'rest_api_init', function () {
    register_rest_route( 'fsoma/v1', '/generate-token', array(
        'methods'             => 'POST',
        'callback'            => 'fsoma_generate_token_endpoint',
        'permission_callback' => '__return_true', // public endpoint; change if you want stricter control
    ));
});

function fsoma_generate_token_endpoint( WP_REST_Request $request ) {
    global $wpdb;

    $params = $request->get_json_params();
    if ( empty( $params ) ) {
        $params = $request->get_params();
    }

    $user_id = isset( $params['user_id'] ) ? intval( $params['user_id'] ) : null;
    $user_email = isset( $params['user_email'] ) ? sanitize_email( $params['user_email'] ) : '';

    // shipping_billing may be an array or a JSON-encoded string
    $shipping_billing = array();
    if ( isset( $params['shipping_billing'] ) ) {
        if ( is_string( $params['shipping_billing'] ) ) {
            $decoded = json_decode( $params['shipping_billing'], true );
            if ( is_array( $decoded ) ) {
                $shipping_billing = $decoded;
            } else {
                // if it was double-encoded or something, try stripslashes then decode
                $decoded2 = json_decode( stripslashes( $params['shipping_billing'] ), true );
                $shipping_billing = is_array( $decoded2 ) ? $decoded2 : array();
            }
        } elseif ( is_array( $params['shipping_billing'] ) ) {
            $shipping_billing = $params['shipping_billing'];
        }
    }

    $billing = isset( $shipping_billing['billing'] ) && is_array( $shipping_billing['billing'] ) ? $shipping_billing['billing'] : array();
    $shipping = isset( $shipping_billing['shipping'] ) && is_array( $shipping_billing['shipping'] ) ? $shipping_billing['shipping'] : array();

    // Helper to get sanitized value or empty string
    $get = function( $arr, $key ) {
        return isset( $arr[ $key ] ) ? trim( wp_strip_all_tags( $arr[ $key ] ) ) : '';
    };

    // Billing fields
    $billing_first_name = $get( $billing, 'first_name' );
    $billing_last_name  = $get( $billing, 'last_name' );
    $billing_company    = $get( $billing, 'company' );
    $billing_address_1  = $get( $billing, 'address_1' );
    $billing_address_2  = $get( $billing, 'address_2' );
    $billing_city       = $get( $billing, 'city' );
    $billing_state      = $get( $billing, 'state' );
    $billing_postcode   = $get( $billing, 'postcode' );
    $billing_country    = $get( $billing, 'country' );
    $billing_phone      = $get( $billing, 'phone' );
    $billing_email      = $get( $billing, 'email' );

    // Shipping fields
    $shipping_first_name = $get( $shipping, 'first_name' );
    $shipping_last_name  = $get( $shipping, 'last_name' );
    $shipping_company    = $get( $shipping, 'company' );
    $shipping_address_1  = $get( $shipping, 'address_1' );
    $shipping_address_2  = $get( $shipping, 'address_2' );
    $shipping_city       = $get( $shipping, 'city' );
    $shipping_state      = $get( $shipping, 'state' );
    $shipping_postcode   = $get( $shipping, 'postcode' );
    $shipping_country    = $get( $shipping, 'country' );
    $shipping_phone      = $get( $shipping, 'phone' );

    // If shipping phone is empty, fall back to billing phone (optional)
    if ( empty( $shipping_phone ) ) {
        $shipping_phone = $billing_phone;
    }

    // generate token and dates
    $token = wp_generate_password(32, false);
    $generated_on = date('Y-m-d H:i:s');
    $expiry_minutes = 30;
    $expiry_date = date('Y-m-d H:i:s', strtotime('+'.$expiry_minutes.' minutes'));

    // Table name
    $table_name = $wpdb->prefix . 'tcmreview_tokens';

    // Insert or update row with extra fields
    $sql = $wpdb->prepare(
        "
        INSERT INTO $table_name
            (user_id, user_email, user_phone, token, token_generated, expiry_date,
             billing_first_name, billing_last_name, billing_company, billing_address_1, billing_address_2,
             billing_city, billing_state, billing_postcode, billing_country, billing_phone, billing_email,
             shipping_first_name, shipping_last_name, shipping_company, shipping_address_1, shipping_address_2,
             shipping_city, shipping_state, shipping_postcode, shipping_country, shipping_phone)
        VALUES
            (%d, %s, %s, %s, %s, %s,
             %s, %s, %s, %s, %s,
             %s, %s, %s, %s, %s, %s,
             %s, %s, %s, %s, %s,
             %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE
            token = VALUES(token),
            token_generated = VALUES(token_generated),
            expiry_date = VALUES(expiry_date),
            user_email = VALUES(user_email),
            user_phone = VALUES(user_phone),
            billing_first_name = VALUES(billing_first_name),
            billing_last_name = VALUES(billing_last_name),
            billing_company = VALUES(billing_company),
            billing_address_1 = VALUES(billing_address_1),
            billing_address_2 = VALUES(billing_address_2),
            billing_city = VALUES(billing_city),
            billing_state = VALUES(billing_state),
            billing_postcode = VALUES(billing_postcode),
            billing_country = VALUES(billing_country),
            billing_phone = VALUES(billing_phone),
            billing_email = VALUES(billing_email),
            shipping_first_name = VALUES(shipping_first_name),
            shipping_last_name = VALUES(shipping_last_name),
            shipping_company = VALUES(shipping_company),
            shipping_address_1 = VALUES(shipping_address_1),
            shipping_address_2 = VALUES(shipping_address_2),
            shipping_city = VALUES(shipping_city),
            shipping_state = VALUES(shipping_state),
            shipping_postcode = VALUES(shipping_postcode),
            shipping_country = VALUES(shipping_country),
            shipping_phone = VALUES(shipping_phone)
        ",
        // values in same order as placeholders
        $user_id,
        $user_email,
        $billing_phone,    // user_phone (optional: you can change to a dedicated param if you have one)
        $token,
        $generated_on,
        $expiry_date,

        // billing
        $billing_first_name,
        $billing_last_name,
        $billing_company,
        $billing_address_1,
        $billing_address_2,
        $billing_city,
        $billing_state,
        $billing_postcode,
        $billing_country,
        $billing_phone,
        $billing_email,

        // shipping
        $shipping_first_name,
        $shipping_last_name,
        $shipping_company,
        $shipping_address_1,
        $shipping_address_2,
        $shipping_city,
        $shipping_state,
        $shipping_postcode,
        $shipping_country,
        $shipping_phone
    );

    $wpdb->query( $sql );

    return new WP_REST_Response( array(
        'success'       => true,
        'token'         => $token,
        'token_expiry'  => $expiry_minutes,
    ), 200 );
}



 
/**
 * Validate token.
 * Replace the body of this function with your own validation (DB/API/etc).
 *
 * Return true for valid, false for invalid.
 *
 * @param string $token
 * @return bool
 */
function fsoma_validate_token( $token ) {
global $wpdb; 
	$token = trim( (string) $token );
	if ( $token === '' ) {
		return false;
	} 
	// Explicit table name (no WP prefix)
	$table = $wpdb->prefix .'tcmreview_tokens';

	// Safety: ensure table exists in this DB
	$like = $wpdb->esc_like( $table );
	$found_table = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $like ) );
	if ( $found_table !== $table ) {
		// Table missing — treat as invalid (or log for debugging)
		if ( function_exists( 'error_log' ) ) {
			error_log( sprintf( '[fsoma-token] DB table missing: %s', $table ) );
		}
		return false;
	}

	// Query token row: select token_generated and expiry_date
	$sql = $wpdb->prepare(
		"SELECT token_generated, expiry_date
		 FROM {$table}
		 WHERE token = %s
		 LIMIT 1",
		$token
	);
 
	$row = $wpdb->get_row( $sql, ARRAY_A );
 
	// Not found
	if ( empty( $row ) ) {  
		return false;
	}
 
	// If expiry_date is empty/null -> treat as non-expiring (valid)
	if ( empty( $row['expiry_date'] ) ) {
		return true;
	}

	// Parse expiry_date (strtotime should handle common DATETIME formats)
	$expires_ts = strtotime( $row['expiry_date'] );
 

	// Use WP current_time to respect WP timezone settings
	$now_ts =  strtotime(date('Y-m-d H:i:s'));
 
	$grace_window = 30 * 60;

// If token expired more than 30 minutes ago — invalid
if ( ($now_ts - $expires_ts) > $grace_window ) {
    return false;
}
$token_expiry_insec = abs($now_ts - $expires_ts);
  
    setcookie(
        'fsoma_token',   // name
        $token,              // value
        time() +  $token_expiry_insec,       // expires in 1 hour
        '/',                 // path
        '',                  // domain (empty = current domain)
        $is_https,           // secure
        true                 // httponly
    );
	// not expired -> valid

   
   //   wp_safe_redirect( remove_query_arg('fsoma_token') );
    return true;

 
}

 
/**
 * Execute token check only for front-end requests to /fsoma/ path
 * If token exists and is invalid => redirect to https://adavibes.com/
 */ 
add_action('template_redirect', function() {
	if ( !(isset($_COOKIE['fsoma_token']) ) ) {	 
		$uri = ( ! empty( $_SERVER['REQUEST_URI'] ) ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$path = parse_url( $uri, PHP_URL_PATH );
		if ( $path === null ) {
			return;
		}
		// Normalize trailing slash — we want to match /fsoma and /fsoma/
		$path = untrailingslashit( $path );
		$fsoma_path = '/fsoma';

		// If your site is in a subdirectory, you may need to include the subdir here,
		// e.g. $fsoma_path = '/subdir/fsoma';
		if ( strpos( $path, $fsoma_path ) !== 0 ) {
			// not /fsoma -> ignore
			return;
		}

		// Skip admin, cron, REST, AJAX or CLI
		if ( is_admin()
		|| ( defined( 'REST_REQUEST' ) && REST_REQUEST )
		|| ( defined( 'DOING_AJAX' ) && DOING_AJAX )
		|| ( defined( 'WP_CLI' ) && WP_CLI )
		|| ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() )
		) {
			return;
		}

		// Only handle POST requests
		if ( ! empty( $_SERVER['REQUEST_METHOD'] ) && strtoupper( $_SERVER['REQUEST_METHOD'] ) !== 'POST' ) {
			handle_invalid_token();
		}


		// Quick check: token present?
		if ( ! isset( $_POST['token'] ) ) {
			handle_invalid_token();
		}
		$token = wp_unslash( $_POST['token'] );
		$token = trim( $token );

		if ( $token === '' ) {
			handle_invalid_token();
		}
		// Determine request path. Use REQUEST_URI so it works behind proxies; strip query.
		$uri = ( ! empty( $_SERVER['REQUEST_URI'] ) ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$path = parse_url( $uri, PHP_URL_PATH );
		if ( $path === null ) {
			handle_invalid_token();
		} 

		// At this point: token exists and request path is /fsoma (or child path). Validate!
		$is_valid = fsoma_validate_token( $token );
		if ( ! $is_valid ) {
			handle_invalid_token();
		} 
	}
});

function  handle_invalid_token(){
	$redirect_to = 'https://adavibes.com/?tcm-token=error';

	// Optional logging for debugging (can be removed later)
	if ( function_exists( 'error_log' ) ) {
	error_log( sprintf( '[fsoma-token] Invalid token detected: %s — redirecting to %s', substr( $token, 0, 64 ), $redirect_to ) );
	}

	// Perform redirect. Use 302 for temporary; change to 301 if permanent.
	wp_redirect( $redirect_to, 302 );
	exit;
}


//prefill user info in checkout

/**
 * Prefill WooCommerce checkout fields from token stored in cookie fsoma_token
 */
add_filter( 'woocommerce_checkout_get_value', 'fsoma_prefill_checkout_fields_from_cookie', 10, 2 );

function fsoma_prefill_checkout_fields_from_cookie( $value, $input_name ) {

    // Only proceed if cookie exists
    if ( empty( $_COOKIE['fsoma_token'] ) ) {
        return $value;
    }

    $token = sanitize_text_field( $_COOKIE['fsoma_token'] );
    global $wpdb;

    $table = 'kfeul_tcmreview_tokens';

    // Fetch all relevant fields for this token
    $fields = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT 
                user_email, user_phone,
                billing_first_name, billing_last_name, billing_company, billing_address_1, billing_address_2, billing_city, billing_state, billing_postcode, billing_country, billing_phone, billing_email,
                shipping_first_name, shipping_last_name, shipping_company, shipping_address_1, shipping_address_2, shipping_city, shipping_state, shipping_postcode, shipping_country, shipping_phone
             FROM {$table} WHERE token = %s LIMIT 1",
            $token
        ),
        ARRAY_A
    );

    if ( empty( $fields ) ) {
        return $value;
    }

    // Map input_name to DB columns
    $field_map = array(
        // Billing
        'billing_first_name' => 'billing_first_name',
        'billing_last_name'  => 'billing_last_name',
        'billing_company'    => 'billing_company',
        'billing_address_1'  => 'billing_address_1',
        'billing_address_2'  => 'billing_address_2',
        'billing_city'       => 'billing_city',
        'billing_state'      => 'billing_state',
        'billing_postcode'   => 'billing_postcode',
        'billing_country'    => 'billing_country',
        'billing_email'      => 'billing_email', // fallback to user_email if empty
        'billing_phone'      => 'billing_phone',

        // Shipping
        'shipping_first_name' => 'shipping_first_name',
        'shipping_last_name'  => 'shipping_last_name',
        'shipping_company'    => 'shipping_company',
        'shipping_address_1'  => 'shipping_address_1',
        'shipping_address_2'  => 'shipping_address_2',
        'shipping_city'       => 'shipping_city',
        'shipping_state'      => 'shipping_state',
        'shipping_postcode'   => 'shipping_postcode',
        'shipping_country'    => 'shipping_country',
        'shipping_phone'      => 'shipping_phone',
    );

    if ( isset( $field_map[ $input_name ] ) && ! empty( $fields[ $field_map[ $input_name ] ] ) ) {
        $prefill_value = $fields[ $field_map[ $input_name ] ];

        // Fallback for billing_email if empty in DB
        if ( 'billing_email' === $input_name && empty( $prefill_value ) && ! empty( $fields['user_email'] ) ) {
            $prefill_value = $fields['user_email'];
        }

        return sanitize_text_field( $prefill_value );
    }

    return $value;
}
